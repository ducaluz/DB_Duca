begin; 

CREATE TABLE comp_compras( 
      id  INT IDENTITY    NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_custos( 
      id  INT IDENTITY    NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_detalhes( 
      id  INT IDENTITY    NOT NULL  , 
      comp_compras_id int   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_estoques( 
      id  INT IDENTITY    NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_produtos( 
      id  INT IDENTITY    NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_produtosvol( 
      id  INT IDENTITY    NOT NULL  , 
      comp_produtos_id int   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_request( 
      id  INT IDENTITY    NOT NULL  , 
      ordemproducao int   NOT NULL  , 
      sequencia int   NOT NULL  , 
      codprod int   NOT NULL  , 
      qtdneg int   NOT NULL  , 
      codemp int   NOT NULL  , 
      codlocalorig int   NOT NULL  , 
      codlocaldest int   NOT NULL  , 
      dhinc datetime2   , 
      dhalter datetime2   , 
      dhsync datetime2   , 
      tipo varchar  (1)   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_vendas( 
      id  INT IDENTITY    NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_vendasdetalhe( 
      id  INT IDENTITY    NOT NULL  , 
      comp_vendas_id int   NOT NULL  , 
 PRIMARY KEY (id)); 

  
 ALTER TABLE comp_request ADD UNIQUE (ordemproducao);
  
 ALTER TABLE comp_detalhes ADD CONSTRAINT fk_comp_detalhes_1 FOREIGN KEY (comp_compras_id) references comp_compras(id); 
ALTER TABLE comp_produtosvol ADD CONSTRAINT fk_comp_produtosvol_1 FOREIGN KEY (comp_produtos_id) references comp_produtos(id); 
ALTER TABLE comp_vendasdetalhe ADD CONSTRAINT fk_comp_vendasdetalhe_1 FOREIGN KEY (comp_vendas_id) references comp_vendas(id); 

  
 
 commit;