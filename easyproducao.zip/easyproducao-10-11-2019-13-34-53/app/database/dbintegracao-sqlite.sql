begin; 

PRAGMA foreign_keys=OFF; 

CREATE TABLE comp_compras( 
      id  INTEGER    NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_custos( 
      id  INTEGER    NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_detalhes( 
      id  INTEGER    NOT NULL  , 
      comp_compras_id int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(comp_compras_id) REFERENCES comp_compras(id)); 

 CREATE TABLE comp_estoques( 
      id  INTEGER    NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_produtos( 
      id  INTEGER    NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_produtosvol( 
      id  INTEGER    NOT NULL  , 
      comp_produtos_id int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(comp_produtos_id) REFERENCES comp_produtos(id)); 

 CREATE TABLE comp_request( 
      id  INTEGER    NOT NULL  , 
      ordemproducao int   NOT NULL  , 
      sequencia int   NOT NULL  , 
      codprod int   NOT NULL  , 
      qtdneg int   NOT NULL  , 
      codemp int   NOT NULL  , 
      codlocalorig int   NOT NULL  , 
      codlocaldest int   NOT NULL  , 
      dhinc datetime   , 
      dhalter datetime   , 
      dhsync datetime   , 
      tipo varchar  (1)   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_vendas( 
      id  INTEGER    NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_vendasdetalhe( 
      id  INTEGER    NOT NULL  , 
      comp_vendas_id int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(comp_vendas_id) REFERENCES comp_vendas(id)); 

  
 CREATE UNIQUE INDEX idx_comp_request_ordemproducao ON comp_request(ordemproducao);
 
  
 
 commit;