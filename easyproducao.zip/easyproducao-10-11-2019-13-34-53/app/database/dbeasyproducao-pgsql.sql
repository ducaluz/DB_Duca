begin; 

CREATE TABLE feriados( 
      id  SERIAL    NOT NULL  , 
      dataferiado date   NOT NULL  , 
      descricao char  (50)   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE fichaitens( 
      quantidade float   NOT NULL  , 
      id  SERIAL    NOT NULL  , 
      tempo integer     DEFAULT 0, 
      fichatecnica_id integer   NOT NULL  , 
      produto_id integer   NOT NULL  , 
      setor_id integer   NOT NULL  , 
      observacao text   , 
 PRIMARY KEY (id)); 

 CREATE TABLE fichatecnica( 
      id  SERIAL    NOT NULL  , 
      versao text   NOT NULL  , 
      rendimento float   NOT NULL    DEFAULT 1, 
      created timestamp   NOT NULL  , 
      modified timestamp   NOT NULL  , 
      produto_id integer   NOT NULL  , 
      pesofinal text     DEFAULT '0', 
      dias integer     DEFAULT 0, 
      tipo char  (1)   NOT NULL    DEFAULT 'E', 
 PRIMARY KEY (id)); 

 CREATE TABLE lote( 
      id  SERIAL    NOT NULL  , 
      datalote date   NOT NULL    DEFAULT 'date()+2', 
      codigo char  (50)   , 
      semana integer   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE loteitens( 
      id  SERIAL    NOT NULL  , 
      lote_id integer   NOT NULL  , 
      fichatecnica_id integer   NOT NULL  , 
      quantidade integer   NOT NULL  , 
      setor_id integer   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE movimentoproducao( 
      id  SERIAL    NOT NULL  , 
      datamovimento date   NOT NULL  , 
      tipomovimento_id integer   NOT NULL  , 
      ordem_id integer   NOT NULL  , 
      setor_id integer   NOT NULL  , 
      quantidade integer   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE ocorrencia( 
      id  SERIAL    NOT NULL  , 
      dataocorrencia date   NOT NULL  , 
      datainicio timestamp   NOT NULL  , 
      datafinal timestamp   NOT NULL  , 
      descricao text   NOT NULL  , 
      setor_id integer   , 
      tipomovimento_id integer   , 
      executor text   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE ordemproducao( 
      id  SERIAL    NOT NULL  , 
      dataproducao date   NOT NULL  , 
      quantidade float   NOT NULL  , 
      status text   NOT NULL  , 
      fichatecnica_id integer   NOT NULL  , 
      loteitens_id integer   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE ordemproducao_sintetico( 
      id  SERIAL    NOT NULL  , 
      dataproducao date   , 
      fichatecnica_id integer   , 
      semana integer   , 
      nomeficha varchar  (100)   , 
      qtde float     DEFAULT 3, 
      estado char  (1)   , 
 PRIMARY KEY (id)); 

 CREATE TABLE produto( 
      id  SERIAL    NOT NULL  , 
      descricao text   NOT NULL  , 
      unidade text   NOT NULL  , 
      final char  (1)   NOT NULL    DEFAULT '2', 
      created timestamp   NOT NULL  , 
      modified timestamp   NOT NULL  , 
      codigojiwa text   NOT NULL  , 
      qtdecaixa integer     DEFAULT 0, 
      qtdesaco integer     DEFAULT 0, 
 PRIMARY KEY (id)); 

 CREATE TABLE produtofatorcorrecao( 
      id  SERIAL    NOT NULL  , 
      datafator date   NOT NULL  , 
      fator float   NOT NULL    DEFAULT 1, 
      produto_id integer   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE separa_produtos_dia( 
      lote_id integer   NOT NULL  , 
      dataproducao date   , 
      ordem integer   , 
      setor varchar  (200)   , 
      produto varchar  (200)   , 
      qtde_produto float     DEFAULT 3, 
      un varchar  (2)   , 
      setor_id integer   , 
      produto_id integer   , 
 PRIMARY KEY (lote_id)); 

 CREATE TABLE separa_produtos_ficha( 
      ordemproducao_id integer   NOT NULL  , 
      dataproducao date   , 
      quantidade_ficha float     DEFAULT 3, 
      fichatecnica_id integer   , 
      descricao_ficha varchar  (200)   , 
      produto varchar  (200)   , 
      qtde_produto float     DEFAULT 3, 
      un varchar  (2)   , 
      setor varchar  (50)   , 
      lote_id integer   , 
 PRIMARY KEY (ordemproducao_id)); 

 CREATE TABLE setor( 
      id  SERIAL    NOT NULL  , 
      descricao text   NOT NULL  , 
      capacidade integer     DEFAULT 0, 
      localestoque integer   , 
      created timestamp   NOT NULL  , 
      modified timestamp   NOT NULL  , 
      ordem integer     DEFAULT 1, 
 PRIMARY KEY (id)); 

 CREATE TABLE tipomovimento( 
      id  SERIAL    NOT NULL  , 
      descricao text   NOT NULL  , 
      created timestamp   NOT NULL  , 
      modified timestamp   NOT NULL  , 
      entradasaida char  (1)   NOT NULL    DEFAULT '1', 
 PRIMARY KEY (id)); 

  
 ALTER TABLE feriados ADD UNIQUE (dataferiado);
 ALTER TABLE lote ADD UNIQUE (datalote);
  
 ALTER TABLE fichaitens ADD CONSTRAINT fk_fichaitens_1 FOREIGN KEY (fichatecnica_id) references fichatecnica(id); 
ALTER TABLE fichaitens ADD CONSTRAINT fk_fichaitens_2 FOREIGN KEY (produto_id) references produto(id); 
ALTER TABLE fichaitens ADD CONSTRAINT fk_fichaitens_3 FOREIGN KEY (setor_id) references setor(id); 
ALTER TABLE fichatecnica ADD CONSTRAINT fk_fichatecnica_1 FOREIGN KEY (produto_id) references produto(id); 
ALTER TABLE loteitens ADD CONSTRAINT fk_loteitens_1 FOREIGN KEY (lote_id) references lote(id); 
ALTER TABLE loteitens ADD CONSTRAINT fk_loteitens_2 FOREIGN KEY (fichatecnica_id) references fichatecnica(id); 
ALTER TABLE loteitens ADD CONSTRAINT fk_loteitens_3 FOREIGN KEY (setor_id) references setor(id); 
ALTER TABLE movimentoproducao ADD CONSTRAINT fk_movimentoproducao_1 FOREIGN KEY (ordem_id) references ordemproducao(id); 
ALTER TABLE movimentoproducao ADD CONSTRAINT fk_movimentoproducao_2 FOREIGN KEY (setor_id) references setor(id); 
ALTER TABLE movimentoproducao ADD CONSTRAINT fk_movimentoproducao_3 FOREIGN KEY (tipomovimento_id) references tipomovimento(id); 
ALTER TABLE ocorrencia ADD CONSTRAINT fk_ocorrencia_1 FOREIGN KEY (setor_id) references setor(id); 
ALTER TABLE ocorrencia ADD CONSTRAINT fk_ocorrencia_2 FOREIGN KEY (tipomovimento_id) references tipomovimento(id); 
ALTER TABLE ordemproducao ADD CONSTRAINT fk_ordemproducao_1 FOREIGN KEY (fichatecnica_id) references fichatecnica(id); 
ALTER TABLE ordemproducao ADD CONSTRAINT fk_ordemproducao_2 FOREIGN KEY (loteitens_id) references loteitens(id); 
ALTER TABLE produtofatorcorrecao ADD CONSTRAINT fk_produtofatorcorrecao_1 FOREIGN KEY (produto_id) references produto(id); 

  
 
 commit;