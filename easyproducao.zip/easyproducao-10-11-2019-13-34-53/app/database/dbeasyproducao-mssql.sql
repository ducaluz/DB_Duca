begin; 

CREATE TABLE feriados( 
      id  INT IDENTITY    NOT NULL  , 
      dataferiado date   NOT NULL  , 
      descricao char  (50)   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE fichaitens( 
      quantidade float   NOT NULL  , 
      id  INT IDENTITY    NOT NULL  , 
      tempo int     DEFAULT 0, 
      fichatecnica_id int   NOT NULL  , 
      produto_id int   NOT NULL  , 
      setor_id int   NOT NULL  , 
      observacao nvarchar(max)   , 
 PRIMARY KEY (id)); 

 CREATE TABLE fichatecnica( 
      id  INT IDENTITY    NOT NULL  , 
      versao nvarchar(max)   NOT NULL  , 
      rendimento float  (10)   NOT NULL    DEFAULT 1, 
      created datetime2   NOT NULL  , 
      modified datetime2   NOT NULL  , 
      produto_id int   NOT NULL  , 
      pesofinal nvarchar(max)     DEFAULT '0', 
      dias int  (2)     DEFAULT 0, 
      tipo char  (1)   NOT NULL    DEFAULT 'E', 
 PRIMARY KEY (id)); 

 CREATE TABLE lote( 
      id  INT IDENTITY    NOT NULL  , 
      datalote date   NOT NULL    DEFAULT 'date()+2', 
      codigo char  (50)   , 
      semana int  (2)   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE loteitens( 
      id  INT IDENTITY    NOT NULL  , 
      lote_id int   NOT NULL  , 
      fichatecnica_id int   NOT NULL  , 
      quantidade int   NOT NULL  , 
      setor_id int   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE movimentoproducao( 
      id  INT IDENTITY    NOT NULL  , 
      datamovimento date   NOT NULL  , 
      tipomovimento_id int   NOT NULL  , 
      ordem_id int   NOT NULL  , 
      setor_id int   NOT NULL  , 
      quantidade int   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE ocorrencia( 
      id  INT IDENTITY    NOT NULL  , 
      dataocorrencia date   NOT NULL  , 
      datainicio datetime2   NOT NULL  , 
      datafinal datetime2   NOT NULL  , 
      descricao nvarchar(max)   NOT NULL  , 
      setor_id int   , 
      tipomovimento_id int   , 
      executor nvarchar(max)   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE ordemproducao( 
      id  INT IDENTITY    NOT NULL  , 
      dataproducao date   NOT NULL  , 
      quantidade float  (10)   NOT NULL  , 
      status nvarchar(max)   NOT NULL  , 
      fichatecnica_id int   NOT NULL  , 
      loteitens_id int   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE ordemproducao_sintetico( 
      id  INT IDENTITY    NOT NULL  , 
      dataproducao date   , 
      fichatecnica_id int   , 
      semana int   , 
      nomeficha varchar  (100)   , 
      qtde float  (10)     DEFAULT 3, 
      estado char  (1)   , 
 PRIMARY KEY (id)); 

 CREATE TABLE produto( 
      id  INT IDENTITY    NOT NULL  , 
      descricao nvarchar(max)   NOT NULL  , 
      unidade nvarchar(max)   NOT NULL  , 
      final char  (1)   NOT NULL    DEFAULT '2', 
      created datetime2   NOT NULL  , 
      modified datetime2   NOT NULL  , 
      codigojiwa nvarchar(max)   NOT NULL  , 
      qtdecaixa int     DEFAULT 0, 
      qtdesaco int     DEFAULT 0, 
 PRIMARY KEY (id)); 

 CREATE TABLE produtofatorcorrecao( 
      id  INT IDENTITY    NOT NULL  , 
      datafator date   NOT NULL  , 
      fator float  (10)   NOT NULL    DEFAULT 1, 
      produto_id int   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE separa_produtos_dia( 
      lote_id int   NOT NULL  , 
      dataproducao date   , 
      ordem int   , 
      setor varchar  (200)   , 
      produto varchar  (200)   , 
      qtde_produto float  (10)     DEFAULT 3, 
      un varchar  (2)   , 
      setor_id int   , 
      produto_id int   , 
 PRIMARY KEY (lote_id)); 

 CREATE TABLE separa_produtos_ficha( 
      ordemproducao_id int   NOT NULL  , 
      dataproducao date   , 
      quantidade_ficha float  (10)     DEFAULT 3, 
      fichatecnica_id int   , 
      descricao_ficha varchar  (200)   , 
      produto varchar  (200)   , 
      qtde_produto float  (10 )     DEFAULT 3, 
      un varchar  (2)   , 
      setor varchar  (50)   , 
      lote_id int   , 
 PRIMARY KEY (ordemproducao_id)); 

 CREATE TABLE setor( 
      id  INT IDENTITY    NOT NULL  , 
      descricao nvarchar(max)   NOT NULL  , 
      capacidade int     DEFAULT 0, 
      localestoque int   , 
      created datetime2   NOT NULL  , 
      modified datetime2   NOT NULL  , 
      ordem int     DEFAULT 1, 
 PRIMARY KEY (id)); 

 CREATE TABLE tipomovimento( 
      id  INT IDENTITY    NOT NULL  , 
      descricao nvarchar(max)   NOT NULL  , 
      created datetime2   NOT NULL  , 
      modified datetime2   NOT NULL  , 
      entradasaida char  (1)   NOT NULL    DEFAULT '1', 
 PRIMARY KEY (id)); 

  
 ALTER TABLE feriados ADD UNIQUE (dataferiado);
 ALTER TABLE lote ADD UNIQUE (datalote);
  
 ALTER TABLE fichaitens ADD CONSTRAINT fk_fichaitens_1 FOREIGN KEY (fichatecnica_id) references fichatecnica(id); 
ALTER TABLE fichaitens ADD CONSTRAINT fk_fichaitens_2 FOREIGN KEY (produto_id) references produto(id); 
ALTER TABLE fichaitens ADD CONSTRAINT fk_fichaitens_3 FOREIGN KEY (setor_id) references setor(id); 
ALTER TABLE fichatecnica ADD CONSTRAINT fk_fichatecnica_1 FOREIGN KEY (produto_id) references produto(id); 
ALTER TABLE loteitens ADD CONSTRAINT fk_loteitens_1 FOREIGN KEY (lote_id) references lote(id); 
ALTER TABLE loteitens ADD CONSTRAINT fk_loteitens_2 FOREIGN KEY (fichatecnica_id) references fichatecnica(id); 
ALTER TABLE loteitens ADD CONSTRAINT fk_loteitens_3 FOREIGN KEY (setor_id) references setor(id); 
ALTER TABLE movimentoproducao ADD CONSTRAINT fk_movimentoproducao_1 FOREIGN KEY (ordem_id) references ordemproducao(id); 
ALTER TABLE movimentoproducao ADD CONSTRAINT fk_movimentoproducao_2 FOREIGN KEY (setor_id) references setor(id); 
ALTER TABLE movimentoproducao ADD CONSTRAINT fk_movimentoproducao_3 FOREIGN KEY (tipomovimento_id) references tipomovimento(id); 
ALTER TABLE ocorrencia ADD CONSTRAINT fk_ocorrencia_1 FOREIGN KEY (setor_id) references setor(id); 
ALTER TABLE ocorrencia ADD CONSTRAINT fk_ocorrencia_2 FOREIGN KEY (tipomovimento_id) references tipomovimento(id); 
ALTER TABLE ordemproducao ADD CONSTRAINT fk_ordemproducao_1 FOREIGN KEY (fichatecnica_id) references fichatecnica(id); 
ALTER TABLE ordemproducao ADD CONSTRAINT fk_ordemproducao_2 FOREIGN KEY (loteitens_id) references loteitens(id); 
ALTER TABLE produtofatorcorrecao ADD CONSTRAINT fk_produtofatorcorrecao_1 FOREIGN KEY (produto_id) references produto(id); 

  
 
 commit;