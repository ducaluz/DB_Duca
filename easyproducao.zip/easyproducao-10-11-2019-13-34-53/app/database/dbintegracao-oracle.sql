begin; 

CREATE TABLE comp_compras( 
      id number(10)    NOT NULL , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_custos( 
      id number(10)    NOT NULL , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_detalhes( 
      id number(10)    NOT NULL , 
      comp_compras_id number(10)    NOT NULL , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_estoques( 
      id number(10)    NOT NULL , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_produtos( 
      id number(10)    NOT NULL , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_produtosvol( 
      id number(10)    NOT NULL , 
      comp_produtos_id number(10)    NOT NULL , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_request( 
      id number(10)    NOT NULL , 
      ordemproducao number(10)    NOT NULL , 
      sequencia number(10)    NOT NULL , 
      codprod number(10)    NOT NULL , 
      qtdneg number(10)    NOT NULL , 
      codemp number(10)    NOT NULL , 
      codlocalorig number(10)    NOT NULL , 
      codlocaldest number(10)    NOT NULL , 
      dhinc timestamp(0)   , 
      dhalter timestamp(0)   , 
      dhsync timestamp(0)   , 
      tipo varchar  (1)    NOT NULL , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_vendas( 
      id number(10)    NOT NULL , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_vendasdetalhe( 
      id number(10)    NOT NULL , 
      comp_vendas_id number(10)    NOT NULL , 
 PRIMARY KEY (id)); 

  
 ALTER TABLE comp_request ADD UNIQUE (ordemproducao);
  
 ALTER TABLE comp_detalhes ADD CONSTRAINT fk_comp_detalhes_1 FOREIGN KEY (comp_compras_id) references comp_compras(id); 
ALTER TABLE comp_produtosvol ADD CONSTRAINT fk_comp_produtosvol_1 FOREIGN KEY (comp_produtos_id) references comp_produtos(id); 
ALTER TABLE comp_vendasdetalhe ADD CONSTRAINT fk_comp_vendasdetalhe_1 FOREIGN KEY (comp_vendas_id) references comp_vendas(id); 
 CREATE SEQUENCE comp_compras_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER comp_compras_id_seq_tr 

BEFORE INSERT ON comp_compras FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT comp_compras_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE comp_custos_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER comp_custos_id_seq_tr 

BEFORE INSERT ON comp_custos FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT comp_custos_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE comp_detalhes_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER comp_detalhes_id_seq_tr 

BEFORE INSERT ON comp_detalhes FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT comp_detalhes_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE comp_estoques_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER comp_estoques_id_seq_tr 

BEFORE INSERT ON comp_estoques FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT comp_estoques_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE comp_produtos_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER comp_produtos_id_seq_tr 

BEFORE INSERT ON comp_produtos FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT comp_produtos_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE comp_produtosvol_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER comp_produtosvol_id_seq_tr 

BEFORE INSERT ON comp_produtosvol FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT comp_produtosvol_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE comp_request_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER comp_request_id_seq_tr 

BEFORE INSERT ON comp_request FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT comp_request_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE comp_vendas_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER comp_vendas_id_seq_tr 

BEFORE INSERT ON comp_vendas FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT comp_vendas_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE comp_vendasdetalhe_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER comp_vendasdetalhe_id_seq_tr 

BEFORE INSERT ON comp_vendasdetalhe FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT comp_vendasdetalhe_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
 
  
 
 commit;