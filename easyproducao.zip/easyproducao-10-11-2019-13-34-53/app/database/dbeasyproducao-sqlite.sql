begin; 

PRAGMA foreign_keys=OFF; 

CREATE TABLE feriados( 
      id  INTEGER    NOT NULL  , 
      dataferiado date   NOT NULL  , 
      descricao char  (50)   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE fichaitens( 
      quantidade double   NOT NULL  , 
      id  INTEGER    NOT NULL  , 
      tempo int     DEFAULT 0, 
      fichatecnica_id int   NOT NULL  , 
      produto_id int   NOT NULL  , 
      setor_id int   NOT NULL  , 
      observacao text   , 
 PRIMARY KEY (id),
FOREIGN KEY(fichatecnica_id) REFERENCES fichatecnica(id),
FOREIGN KEY(produto_id) REFERENCES produto(id),
FOREIGN KEY(setor_id) REFERENCES setor(id)); 

 CREATE TABLE fichatecnica( 
      id  INTEGER    NOT NULL  , 
      versao text   NOT NULL  , 
      rendimento double  (10)   NOT NULL    DEFAULT 1, 
      created datetime   NOT NULL  , 
      modified datetime   NOT NULL  , 
      produto_id int   NOT NULL  , 
      pesofinal text     DEFAULT '0', 
      dias int  (2)     DEFAULT 0, 
      tipo char  (1)   NOT NULL    DEFAULT 'E', 
 PRIMARY KEY (id),
FOREIGN KEY(produto_id) REFERENCES produto(id)); 

 CREATE TABLE lote( 
      id  INTEGER    NOT NULL  , 
      datalote date   NOT NULL  , 
      codigo char  (50)   , 
      semana int  (2)   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE loteitens( 
      id  INTEGER    NOT NULL  , 
      lote_id int   NOT NULL  , 
      fichatecnica_id int   NOT NULL  , 
      quantidade int   NOT NULL  , 
      setor_id int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(lote_id) REFERENCES lote(id),
FOREIGN KEY(fichatecnica_id) REFERENCES fichatecnica(id),
FOREIGN KEY(setor_id) REFERENCES setor(id)); 

 CREATE TABLE movimentoproducao( 
      id  INTEGER    NOT NULL  , 
      datamovimento date   NOT NULL  , 
      tipomovimento_id int   NOT NULL  , 
      ordem_id int   NOT NULL  , 
      setor_id int   NOT NULL  , 
      quantidade int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(ordem_id) REFERENCES ordemproducao(id),
FOREIGN KEY(setor_id) REFERENCES setor(id),
FOREIGN KEY(tipomovimento_id) REFERENCES tipomovimento(id)); 

 CREATE TABLE ocorrencia( 
      id  INTEGER    NOT NULL  , 
      dataocorrencia date   NOT NULL  , 
      datainicio datetime   NOT NULL  , 
      datafinal datetime   NOT NULL  , 
      descricao text   NOT NULL  , 
      setor_id int   , 
      tipomovimento_id int   , 
      executor text   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(setor_id) REFERENCES setor(id),
FOREIGN KEY(tipomovimento_id) REFERENCES tipomovimento(id)); 

 CREATE TABLE ordemproducao( 
      id  INTEGER    NOT NULL  , 
      dataproducao date   NOT NULL  , 
      quantidade double  (10)   NOT NULL  , 
      status text   NOT NULL  , 
      fichatecnica_id int   NOT NULL  , 
      loteitens_id int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(fichatecnica_id) REFERENCES fichatecnica(id),
FOREIGN KEY(loteitens_id) REFERENCES loteitens(id)); 

 CREATE TABLE ordemproducao_sintetico( 
      id  INTEGER    NOT NULL  , 
      dataproducao date   , 
      fichatecnica_id int   , 
      semana int   , 
      nomeficha varchar  (100)   , 
      qtde double  (10)     DEFAULT 3, 
      estado char  (1)   , 
 PRIMARY KEY (id)); 

 CREATE TABLE produto( 
      id  INTEGER    NOT NULL  , 
      descricao text   NOT NULL  , 
      unidade text   NOT NULL  , 
      final char  (1)   NOT NULL    DEFAULT '2', 
      created datetime   NOT NULL  , 
      modified datetime   NOT NULL  , 
      codigojiwa text   NOT NULL  , 
      qtdecaixa int     DEFAULT 0, 
      qtdesaco int     DEFAULT 0, 
 PRIMARY KEY (id)); 

 CREATE TABLE produtofatorcorrecao( 
      id  INTEGER    NOT NULL  , 
      datafator date   NOT NULL  , 
      fator double  (10)   NOT NULL    DEFAULT 1, 
      produto_id int   NOT NULL  , 
 PRIMARY KEY (id),
FOREIGN KEY(produto_id) REFERENCES produto(id)); 

 CREATE TABLE separa_produtos_dia( 
      lote_id int   NOT NULL  , 
      dataproducao date   , 
      ordem int   , 
      setor varchar  (200)   , 
      produto varchar  (200)   , 
      qtde_produto double  (10)     DEFAULT 3, 
      un varchar  (2)   , 
      setor_id int   , 
      produto_id int   , 
 PRIMARY KEY (lote_id)); 

 CREATE TABLE separa_produtos_ficha( 
      ordemproducao_id int   NOT NULL  , 
      dataproducao date   , 
      quantidade_ficha double  (10)     DEFAULT 3, 
      fichatecnica_id int   , 
      descricao_ficha varchar  (200)   , 
      produto varchar  (200)   , 
      qtde_produto double  (10 )     DEFAULT 3, 
      un varchar  (2)   , 
      setor varchar  (50)   , 
      lote_id int   , 
 PRIMARY KEY (ordemproducao_id)); 

 CREATE TABLE setor( 
      id  INTEGER    NOT NULL  , 
      descricao text   NOT NULL  , 
      capacidade int     DEFAULT 0, 
      localestoque int   , 
      created datetime   NOT NULL  , 
      modified datetime   NOT NULL  , 
      ordem int     DEFAULT 1, 
 PRIMARY KEY (id)); 

 CREATE TABLE tipomovimento( 
      id  INTEGER    NOT NULL  , 
      descricao text   NOT NULL  , 
      created datetime   NOT NULL  , 
      modified datetime   NOT NULL  , 
      entradasaida char  (1)   NOT NULL    DEFAULT '1', 
 PRIMARY KEY (id)); 

  
 CREATE UNIQUE INDEX idx_feriados_dataferiado ON feriados(dataferiado);
 CREATE UNIQUE INDEX idx_lote_datalote ON lote(datalote);
 
  
 
 commit;