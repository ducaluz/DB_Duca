begin; 

CREATE TABLE feriados( 
      id number(10)    NOT NULL , 
      dataferiado date    NOT NULL , 
      descricao char  (50)    NOT NULL , 
 PRIMARY KEY (id)); 

 CREATE TABLE fichaitens( 
      quantidade binary_double    NOT NULL , 
      id number(10)    NOT NULL , 
      tempo number(10)    DEFAULT 0 , 
      fichatecnica_id number(10)    NOT NULL , 
      produto_id number(10)    NOT NULL , 
      setor_id number(10)    NOT NULL , 
      observacao CLOB   , 
 PRIMARY KEY (id)); 

 CREATE TABLE fichatecnica( 
      id number(10)    NOT NULL , 
      versao CLOB    NOT NULL , 
      rendimento binary_double  (10)    DEFAULT 1  NOT NULL , 
      created timestamp(0)    NOT NULL , 
      modified timestamp(0)    NOT NULL , 
      produto_id number(10)    NOT NULL , 
      pesofinal CLOB    DEFAULT '0' , 
      dias number(10)  (2)    DEFAULT 0 , 
      tipo char  (1)    DEFAULT 'E'  NOT NULL , 
 PRIMARY KEY (id)); 

 CREATE TABLE lote( 
      id number(10)    NOT NULL , 
      datalote date    DEFAULT 'date()+2'  NOT NULL , 
      codigo char  (50)   , 
      semana number(10)  (2)    NOT NULL , 
 PRIMARY KEY (id)); 

 CREATE TABLE loteitens( 
      id number(10)    NOT NULL , 
      lote_id number(10)    NOT NULL , 
      fichatecnica_id number(10)    NOT NULL , 
      quantidade number(10)    NOT NULL , 
      setor_id number(10)    NOT NULL , 
 PRIMARY KEY (id)); 

 CREATE TABLE movimentoproducao( 
      id number(10)    NOT NULL , 
      datamovimento date    NOT NULL , 
      tipomovimento_id number(10)    NOT NULL , 
      ordem_id number(10)    NOT NULL , 
      setor_id number(10)    NOT NULL , 
      quantidade number(10)    NOT NULL , 
 PRIMARY KEY (id)); 

 CREATE TABLE ocorrencia( 
      id number(10)    NOT NULL , 
      dataocorrencia date    NOT NULL , 
      datainicio timestamp(0)    NOT NULL , 
      datafinal timestamp(0)    NOT NULL , 
      descricao CLOB    NOT NULL , 
      setor_id number(10)   , 
      tipomovimento_id number(10)   , 
      executor CLOB    NOT NULL , 
 PRIMARY KEY (id)); 

 CREATE TABLE ordemproducao( 
      id number(10)    NOT NULL , 
      dataproducao date    NOT NULL , 
      quantidade binary_double  (10)    NOT NULL , 
      status CLOB    NOT NULL , 
      fichatecnica_id number(10)    NOT NULL , 
      loteitens_id number(10)    NOT NULL , 
 PRIMARY KEY (id)); 

 CREATE TABLE ordemproducao_sintetico( 
      id number(10)    NOT NULL , 
      dataproducao date   , 
      fichatecnica_id number(10)   , 
      semana number(10)   , 
      nomeficha varchar  (100)   , 
      qtde binary_double  (10)    DEFAULT 3 , 
      estado char  (1)   , 
 PRIMARY KEY (id)); 

 CREATE TABLE produto( 
      id number(10)    NOT NULL , 
      descricao CLOB    NOT NULL , 
      unidade CLOB    NOT NULL , 
      final char  (1)    DEFAULT '2'  NOT NULL , 
      created timestamp(0)    NOT NULL , 
      modified timestamp(0)    NOT NULL , 
      codigojiwa CLOB    NOT NULL , 
      qtdecaixa number(10)    DEFAULT 0 , 
      qtdesaco number(10)    DEFAULT 0 , 
 PRIMARY KEY (id)); 

 CREATE TABLE produtofatorcorrecao( 
      id number(10)    NOT NULL , 
      datafator date    NOT NULL , 
      fator binary_double  (10)    DEFAULT 1  NOT NULL , 
      produto_id number(10)    NOT NULL , 
 PRIMARY KEY (id)); 

 CREATE TABLE separa_produtos_dia( 
      lote_id number(10)    NOT NULL , 
      dataproducao date   , 
      ordem number(10)   , 
      setor varchar  (200)   , 
      produto varchar  (200)   , 
      qtde_produto binary_double  (10)    DEFAULT 3 , 
      un varchar  (2)   , 
      setor_id number(10)   , 
      produto_id number(10)   , 
 PRIMARY KEY (lote_id)); 

 CREATE TABLE separa_produtos_ficha( 
      ordemproducao_id number(10)    NOT NULL , 
      dataproducao date   , 
      quantidade_ficha binary_double  (10)    DEFAULT 3 , 
      fichatecnica_id number(10)   , 
      descricao_ficha varchar  (200)   , 
      produto varchar  (200)   , 
      qtde_produto binary_double  (10 )    DEFAULT 3 , 
      un varchar  (2)   , 
      setor varchar  (50)   , 
      lote_id number(10)   , 
 PRIMARY KEY (ordemproducao_id)); 

 CREATE TABLE setor( 
      id number(10)    NOT NULL , 
      descricao CLOB    NOT NULL , 
      capacidade number(10)    DEFAULT 0 , 
      localestoque number(10)   , 
      created timestamp(0)    NOT NULL , 
      modified timestamp(0)    NOT NULL , 
      ordem number(10)    DEFAULT 1 , 
 PRIMARY KEY (id)); 

 CREATE TABLE tipomovimento( 
      id number(10)    NOT NULL , 
      descricao CLOB    NOT NULL , 
      created timestamp(0)    NOT NULL , 
      modified timestamp(0)    NOT NULL , 
      entradasaida char  (1)    DEFAULT '1'  NOT NULL , 
 PRIMARY KEY (id)); 

  
 ALTER TABLE feriados ADD UNIQUE (dataferiado);
 ALTER TABLE lote ADD UNIQUE (datalote);
  
 ALTER TABLE fichaitens ADD CONSTRAINT fk_fichaitens_1 FOREIGN KEY (fichatecnica_id) references fichatecnica(id); 
ALTER TABLE fichaitens ADD CONSTRAINT fk_fichaitens_2 FOREIGN KEY (produto_id) references produto(id); 
ALTER TABLE fichaitens ADD CONSTRAINT fk_fichaitens_3 FOREIGN KEY (setor_id) references setor(id); 
ALTER TABLE fichatecnica ADD CONSTRAINT fk_fichatecnica_1 FOREIGN KEY (produto_id) references produto(id); 
ALTER TABLE loteitens ADD CONSTRAINT fk_loteitens_1 FOREIGN KEY (lote_id) references lote(id); 
ALTER TABLE loteitens ADD CONSTRAINT fk_loteitens_2 FOREIGN KEY (fichatecnica_id) references fichatecnica(id); 
ALTER TABLE loteitens ADD CONSTRAINT fk_loteitens_3 FOREIGN KEY (setor_id) references setor(id); 
ALTER TABLE movimentoproducao ADD CONSTRAINT fk_movimentoproducao_1 FOREIGN KEY (ordem_id) references ordemproducao(id); 
ALTER TABLE movimentoproducao ADD CONSTRAINT fk_movimentoproducao_2 FOREIGN KEY (setor_id) references setor(id); 
ALTER TABLE movimentoproducao ADD CONSTRAINT fk_movimentoproducao_3 FOREIGN KEY (tipomovimento_id) references tipomovimento(id); 
ALTER TABLE ocorrencia ADD CONSTRAINT fk_ocorrencia_1 FOREIGN KEY (setor_id) references setor(id); 
ALTER TABLE ocorrencia ADD CONSTRAINT fk_ocorrencia_2 FOREIGN KEY (tipomovimento_id) references tipomovimento(id); 
ALTER TABLE ordemproducao ADD CONSTRAINT fk_ordemproducao_1 FOREIGN KEY (fichatecnica_id) references fichatecnica(id); 
ALTER TABLE ordemproducao ADD CONSTRAINT fk_ordemproducao_2 FOREIGN KEY (loteitens_id) references loteitens(id); 
ALTER TABLE produtofatorcorrecao ADD CONSTRAINT fk_produtofatorcorrecao_1 FOREIGN KEY (produto_id) references produto(id); 
 CREATE SEQUENCE feriados_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER feriados_id_seq_tr 

BEFORE INSERT ON feriados FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT feriados_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE fichaitens_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER fichaitens_id_seq_tr 

BEFORE INSERT ON fichaitens FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT fichaitens_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE fichatecnica_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER fichatecnica_id_seq_tr 

BEFORE INSERT ON fichatecnica FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT fichatecnica_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE lote_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER lote_id_seq_tr 

BEFORE INSERT ON lote FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT lote_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE loteitens_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER loteitens_id_seq_tr 

BEFORE INSERT ON loteitens FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT loteitens_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE movimentoproducao_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER movimentoproducao_id_seq_tr 

BEFORE INSERT ON movimentoproducao FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT movimentoproducao_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE ocorrencia_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER ocorrencia_id_seq_tr 

BEFORE INSERT ON ocorrencia FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT ocorrencia_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE ordemproducao_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER ordemproducao_id_seq_tr 

BEFORE INSERT ON ordemproducao FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT ordemproducao_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE ordemproducao_sintetico_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER ordemproducao_sintetico_id_seq_tr 

BEFORE INSERT ON ordemproducao_sintetico FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT ordemproducao_sintetico_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE produto_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER produto_id_seq_tr 

BEFORE INSERT ON produto FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT produto_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE produtofatorcorrecao_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER produtofatorcorrecao_id_seq_tr 

BEFORE INSERT ON produtofatorcorrecao FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT produtofatorcorrecao_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE setor_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER setor_id_seq_tr 

BEFORE INSERT ON setor FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT setor_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
CREATE SEQUENCE tipomovimento_id_seq START WITH 1 INCREMENT BY 1; 

CREATE OR REPLACE TRIGGER tipomovimento_id_seq_tr 

BEFORE INSERT ON tipomovimento FOR EACH ROW 

WHEN 

(NEW.id IS NULL) 

BEGIN 

SELECT tipomovimento_id_seq.NEXTVAL INTO :NEW.id FROM DUAL; 

END;
 
  
 
 commit;