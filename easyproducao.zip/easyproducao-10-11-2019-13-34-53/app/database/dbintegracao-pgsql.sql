begin; 

CREATE TABLE comp_compras( 
      id  SERIAL    NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_custos( 
      id  SERIAL    NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_detalhes( 
      id  SERIAL    NOT NULL  , 
      comp_compras_id integer   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_estoques( 
      id  SERIAL    NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_produtos( 
      id  SERIAL    NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_produtosvol( 
      id  SERIAL    NOT NULL  , 
      comp_produtos_id integer   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_request( 
      id  SERIAL    NOT NULL  , 
      ordemproducao integer   NOT NULL  , 
      sequencia integer   NOT NULL  , 
      codprod integer   NOT NULL  , 
      qtdneg integer   NOT NULL  , 
      codemp integer   NOT NULL  , 
      codlocalorig integer   NOT NULL  , 
      codlocaldest integer   NOT NULL  , 
      dhinc timestamp   , 
      dhalter timestamp   , 
      dhsync timestamp   , 
      tipo varchar  (1)   NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_vendas( 
      id  SERIAL    NOT NULL  , 
 PRIMARY KEY (id)); 

 CREATE TABLE comp_vendasdetalhe( 
      id  SERIAL    NOT NULL  , 
      comp_vendas_id integer   NOT NULL  , 
 PRIMARY KEY (id)); 

  
 ALTER TABLE comp_request ADD UNIQUE (ordemproducao);
  
 ALTER TABLE comp_detalhes ADD CONSTRAINT fk_comp_detalhes_1 FOREIGN KEY (comp_compras_id) references comp_compras(id); 
ALTER TABLE comp_produtosvol ADD CONSTRAINT fk_comp_produtosvol_1 FOREIGN KEY (comp_produtos_id) references comp_produtos(id); 
ALTER TABLE comp_vendasdetalhe ADD CONSTRAINT fk_comp_vendasdetalhe_1 FOREIGN KEY (comp_vendas_id) references comp_vendas(id); 

  
 
 commit;