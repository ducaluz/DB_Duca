<?php

class CompRequestForm extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = 'dbintegracao';
    private static $activeRecord = 'CompRequest';
    private static $primaryKey = 'id';
    private static $formName = 'form_CompRequest';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de Request");


        $id = new TEntry('id');
        $ordemproducao = new TDBCombo('ordemproducao', 'dbeasyproducao', 'Ordemproducao', 'id', '{fichatecnica_id}','fichatecnica_id asc'  );
        $sequencia = new TEntry('sequencia');
        $codprod = new TEntry('codprod');
        $qtdneg = new TEntry('qtdneg');
        $codemp = new TEntry('codemp');
        $codlocalorig = new TEntry('codlocalorig');
        $codlocaldest = new TEntry('codlocaldest');
        $dhinc = new TDateTime('dhinc');
        $dhalter = new TDateTime('dhalter');
        $dhsync = new TDateTime('dhsync');
        $tipo = new TEntry('tipo');

        $ordemproducao->addValidation("Ordem Produção", new TRequiredValidator()); 
        $sequencia->addValidation("Sequência", new TRequiredValidator()); 
        $codprod->addValidation("Produto", new TRequiredValidator()); 
        $qtdneg->addValidation("Quantidade", new TRequiredValidator()); 
        $codemp->addValidation("Empresa", new TRequiredValidator()); 
        $codlocalorig->addValidation("Local Origem", new TRequiredValidator()); 
        $codlocaldest->addValidation("Local destino", new TRequiredValidator()); 
        $tipo->addValidation("Tipo", new TRequiredValidator()); 

        $dhinc->setValue(date('d/m/Y hh:ii'));
        $dhalter->setValue(date('d/m/Y hh:ii'));

        $id->setEditable(false);
        $dhinc->setEditable(false);
        $dhalter->setEditable(false);

        $dhinc->setMask('dd/mm/yyyy hh:ii');
        $dhsync->setMask('dd/mm/yyyy hh:ii');
        $dhalter->setMask('dd/mm/yyyy hh:ii');

        $dhinc->setDatabaseMask('yyyy-mm-dd hh:ii');
        $dhsync->setDatabaseMask('yyyy-mm-dd hh:ii');
        $dhalter->setDatabaseMask('yyyy-mm-dd hh:ii');

        $id->setSize(100);
        $dhinc->setSize(142);
        $dhsync->setSize(150);
        $tipo->setSize('70%');
        $dhalter->setSize(142);
        $qtdneg->setSize('70%');
        $codemp->setSize('70%');
        $codprod->setSize('70%');
        $sequencia->setSize('70%');
        $codlocalorig->setSize('73%');
        $codlocaldest->setSize('73%');
        $ordemproducao->setSize('70%');

        $row1 = $this->form->addFields([new TLabel("Id:", null, '14px', null)],[$id]);
        $row2 = $this->form->addFields([new TLabel("Ordem Produção:", '#ff0000', '14px', null)],[$ordemproducao]);
        $row3 = $this->form->addFields([new TLabel("Sequência:", '#ff0000', '14px', null)],[$sequencia]);
        $row4 = $this->form->addFields([new TLabel("Produto:", '#ff0000', '14px', null)],[$codprod]);
        $row5 = $this->form->addFields([new TLabel("Quantidade:", '#ff0000', '14px', null)],[$qtdneg]);
        $row6 = $this->form->addFields([new TLabel("Empresa:", '#ff0000', '14px', null)],[$codemp]);
        $row7 = $this->form->addFields([new TLabel("Local Origem:", '#ff0000', '14px', null)],[$codlocalorig],[new TLabel("Local destino:", '#ff0000', '14px', null)],[$codlocaldest]);
        $row8 = $this->form->addFields([new TLabel("Criado em:", null, '14px', null)],[$dhinc],[new TLabel("Alterado em:", null, '14px', null)],[$dhalter]);
        $row9 = $this->form->addFields([new TLabel("Sincronização:", null, '14px', null)],[$dhsync]);
        $row10 = $this->form->addFields([new TLabel("Tipo:", '#ff0000', '14px', null)],[$tipo]);

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fa:floppy-o #ffffff');
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fa:eraser #dd5a43');

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        // $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        $container->add($this->form);

        parent::add($container);

    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            /**
            // Enable Debug logger for SQL operations inside the transaction
            TTransaction::setLogger(new TLoggerSTD); // standard output
            TTransaction::setLogger(new TLoggerTXT('log.txt')); // file
            **/

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new CompRequest(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $object->store(); // save the object 

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            /**
            // To define an action to be executed on the message close event:
            $messageAction = new TAction(['className', 'methodName']);
            **/

            new TMessage('info', AdiantiCoreTranslator::translate('Record saved'), $messageAction);

        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new CompRequest($key); // instantiates the Active Record 

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

    } 

}

