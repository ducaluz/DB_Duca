<?php
class EmptyPage extends TPage
{

}
?>