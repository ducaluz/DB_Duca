<?php

class FichatecnicaReport extends TPage
{
    private $form; // form
    private $loaded;
    private static $database = 'dbeasyproducao';
    private static $activeRecord = 'Fichatecnica';
    private static $primaryKey = 'id';
    private static $formName = 'formReport_Fichatecnica';

    /**
     * Class constructor
     * Creates the page, the form and the listing
     */
    public function __construct()
    {
        parent::__construct();

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);

        // define the form title
        $this->form->setFormTitle("Relatório de Fichas Técnicas");

        $criteria_produto_id = new TCriteria();

        $filterVar = "S";
        $criteria_produto_id->add(new TFilter('final', '=', $filterVar)); 

        $id = new TEntry('id');
        $tipo = new TCombo('tipo');
        $created = new TDateTime('created');
        $modified = new TDateTime('modified');
        $produto_id = new TDBCombo('produto_id', 'dbeasyproducao', 'Produto', 'id', '{descricao}','descricao asc' , $criteria_produto_id );

        $tipo->addItems(['E'=>'Empanadas','R'=>'Recheio']);

        $created->setMask('dd/mm/yyyy hh:ii');
        $modified->setMask('dd/mm/yyyy hh:ii');

        $created->setDatabaseMask('yyyy-mm-dd hh:ii');
        $modified->setDatabaseMask('yyyy-mm-dd hh:ii');

        $id->setSize(92);
        $tipo->setSize('70%');
        $created->setSize(142);
        $modified->setSize(142);
        $produto_id->setSize('70%');

        $row1 = $this->form->addFields([new TLabel("Id:", null, '14px', null)],[$id],[new TLabel("Tipo:", null, '14px', null)],[$tipo]);
        $row2 = $this->form->addFields([new TLabel("Criado em:", null, '14px', null)],[$created],[new TLabel("Modificado em:", null, '14px', null)],[$modified]);
        $row3 = $this->form->addFields([new TLabel("Produto:", null, '14px', null)],[$produto_id]);

        // keep the form filled during navigation with session data
        $this->form->setData( TSession::getValue(__CLASS__.'_filter_data') );

        $btn_ongeneratehtml = $this->form->addAction("Gerar HTML", new TAction([$this, 'onGenerateHtml']), 'fa:code #ffffff');
        $btn_ongeneratehtml->addStyleClass('btn-primary'); 

        $btn_ongeneratepdf = $this->form->addAction("Gerar PDF", new TAction([$this, 'onGeneratePdf']), 'fa:file-pdf-o #d44734');

        $btn_ongeneratertf = $this->form->addAction("Gerar RTF", new TAction([$this, 'onGenerateRtf']), 'fa:file-text-o #324bcc');

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        $container->add(TBreadCrumb::create(["Relatórios","Fichas Tecnicas"]));
        $container->add($this->form);

        parent::add($container);

    }

    public function onGenerateHtml($param = null) 
    {
        $this->onGenerate('html');
    }
    public function onGeneratePdf($param = null) 
    {
        $this->onGenerate('pdf');
    }
    public function onGenerateRtf($param = null) 
    {
        $this->onGenerate('rtf');
    }

    /**
     * Register the filter in the session
     */
    public function getFilters()
    {
        // get the search form data
        $data = $this->form->getData();

        $filters = [];

        TSession::setValue(__CLASS__.'_filter_data', NULL);
        TSession::setValue(__CLASS__.'_filters', NULL);

        if (isset($data->id) AND ( (is_scalar($data->id) AND $data->id !== '') OR (is_array($data->id) AND (!empty($data->id)) )) )
        {

            $filters[] = new TFilter('id', '=', $data->id);// create the filter 
        }
        if (isset($data->tipo) AND ( (is_scalar($data->tipo) AND $data->tipo !== '') OR (is_array($data->tipo) AND (!empty($data->tipo)) )) )
        {

            $filters[] = new TFilter('tipo', '=', $data->tipo);// create the filter 
        }
        if (isset($data->created) AND ( (is_scalar($data->created) AND $data->created !== '') OR (is_array($data->created) AND (!empty($data->created)) )) )
        {

            $filters[] = new TFilter('created', '=', $data->created);// create the filter 
        }
        if (isset($data->modified) AND ( (is_scalar($data->modified) AND $data->modified !== '') OR (is_array($data->modified) AND (!empty($data->modified)) )) )
        {

            $filters[] = new TFilter('modified', '=', $data->modified);// create the filter 
        }
        if (isset($data->produto_id) AND ( (is_scalar($data->produto_id) AND $data->produto_id !== '') OR (is_array($data->produto_id) AND (!empty($data->produto_id)) )) )
        {

            $filters[] = new TFilter('produto_id', '=', $data->produto_id);// create the filter 
        }

        // fill the form with data again
        $this->form->setData($data);

        // keep the search data in the session
        TSession::setValue(__CLASS__.'_filter_data', $data);

        return $filters;
    }

    public function onGenerate($format)
    {
        try
        {
            $filters = $this->getFilters();
            // open a transaction with database 'dbeasyproducao'
            TTransaction::open(self::$database);
            $param = [];
            // creates a repository for Fichatecnica
            $repository = new TRepository(self::$activeRecord);
            // creates a criteria
            $criteria = new TCriteria;

            $criteria->setProperties($param);

            if ($filters)
            {
                foreach ($filters as $filter) 
                {
                    $criteria->add($filter);       
                }
            }

            // load the objects according to criteria
            $objects = $repository->load($criteria, FALSE);

            if ($objects)
            {
                $widths = array(50,400,50,100,150,150,100,200);

                switch ($format)
                {
                    case 'html':
                        $tr = new TTableWriterHTML($widths);
                        break;
                    case 'xls':
                        $tr = new TTableWriterXLS($widths);
                        break;
                    case 'pdf':
                        $tr = new TTableWriterPDF($widths, 'L');
                        break;
                    case 'rtf':
                        if (!class_exists('PHPRtfLite_Autoloader'))
                        {
                            PHPRtfLite::registerAutoloader();
                        }
                        $tr = new TTableWriterRTF($widths, 'L');
                        break;
                }

                if (!empty($tr))
                {
                    // create the document styles
                    $tr->addStyle('title', 'Helvetica', '10', 'B',   '#000000', '#dbdbdb');
                    $tr->addStyle('datap', 'Arial', '10', '',    '#333333', '#f0f0f0');
                    $tr->addStyle('datai', 'Arial', '10', '',    '#333333', '#ffffff');
                    $tr->addStyle('header', 'Helvetica', '16', 'B',   '#5a5a5a', '#6B6B6B');
                    $tr->addStyle('footer', 'Helvetica', '10', 'B',  '#5a5a5a', '#A3A3A3');
                    $tr->addStyle('break', 'Helvetica', '10', 'B',  '#ffffff', '#9a9a9a');
                    $tr->addStyle('total', 'Helvetica', '10', 'I',  '#000000', '#c7c7c7');
                    $tr->addStyle('breakTotal', 'Helvetica', '10', 'I',  '#000000', '#c6c8d0');

                    $tr->addRow();
                    $tr->addCell('RELAÇÃO DE FICHA TÉCNICAS CADASTRADAS', 'center','title', 8);
                    $tr->addRow();

                    // add titles row
                    $tr->addRow();
                    $tr->addCell("Id", 'center', 'title');
                    $tr->addCell("Produto", 'left', 'title');
                    $tr->addCell("Tipo", 'center', 'title');
                    $tr->addCell("Rendimento", 'right', 'title');
                    $tr->addCell("Criado em", 'center', 'title');
                    $tr->addCell("Modificado em", 'center', 'title');
                    $tr->addCell("Peso final", 'right', 'title');
                    $tr->addCell("Dias Antecipação", 'left', 'title');

                    $grandTotal = [];
                    $breakTotal = [];
                    $breakValue = null;
                    $firstRow = true;

                    // controls the background filling
                    $colour = false;                
                    foreach ($objects as $object)
                    {
                        $style = $colour ? 'datap' : 'datai';

                        $firstRow = false;

                        $object->rendimento = call_user_func(function($value, $object, $row) 
                        {
                            return number_format($value, 3, ',','.') ;

                        }, $object->rendimento, $object, null);

                        $object->created = call_user_func(function($value, $object, $row)
                        {
                            if(!empty(trim($value)))
                            {
                                try
                                {
                                    $date = new DateTime($value);
                                    return $date->format('d/m/Y H:i');
                                }
                                catch (Exception $e)
                                {
                                    return $value;
                                }
                            }
                        }, $object->created, $object, null);

                        $object->modified = call_user_func(function($value, $object, $row)
                        {
                            if(!empty(trim($value)))
                            {
                                try
                                {
                                    $date = new DateTime($value);
                                    return $date->format('d/m/Y H:i');
                                }
                                catch (Exception $e)
                                {
                                    return $value;
                                }
                            }
                        }, $object->modified, $object, null);

                        $tr->addRow();

                        $tr->addCell($object->id, 'center', $style);
                        $tr->addCell($object->produto->descricao, 'left', $style);
                        $tr->addCell($object->tipo, 'center', $style);
                        $tr->addCell($object->rendimento, 'right', $style);
                        $tr->addCell($object->created, 'center', $style);
                        $tr->addCell($object->modified, 'center', $style);
                        $tr->addCell($object->pesofinal, 'right', $style);
                        $tr->addCell($object->dias, 'left', $style);

                        $colour = !$colour;
                    }

                    $file = 'report_'.uniqid().".{$format}";
                    // stores the file
                    if (!file_exists("app/output/{$file}") || is_writable("app/output/{$file}"))
                    {
                        $tr->save("app/output/{$file}");
                    }
                    else
                    {
                        throw new Exception(_t('Permission denied') . ': ' . "app/output/{$file}");
                    }

                    parent::openFile("app/output/{$file}");

                    // shows the success message
                    new TMessage('info', _t('Report generated. Please, enable popups'));
                }
            }
            else
            {
                new TMessage('error', _t('No records found'));
            }

            // close the transaction
            TTransaction::close();
        }
        catch (Exception $e) // in case of exception
        {
            // shows the exception error message
            new TMessage('error', $e->getMessage());
            // undo all pending operations
            TTransaction::rollback();
        }
    }

    public function onShow($param = null)
    {

    }

}

