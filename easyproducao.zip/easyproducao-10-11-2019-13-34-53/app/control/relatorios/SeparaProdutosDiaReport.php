<?php

class SeparaProdutosDiaReport extends TPage
{
    private $form; // form
    private $loaded;
    private static $database = 'dbeasyproducao';
    private static $activeRecord = 'SeparaProdutosDia';
    private static $primaryKey = 'lote_id';
    private static $formName = 'formReport_SeparaProdutosDia';

    /**
     * Class constructor
     * Creates the page, the form and the listing
     */
    public function __construct()
    {
        parent::__construct();

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);

        // define the form title
        $this->form->setFormTitle('Produtos a separar dia');

        $lote_id = new TEntry('lote_id');
        $dataproducao = new TDate('dataproducao');
        $dataFinal = new TDate('dataFinal');
        $setorInicial = new TDBCombo('setorInicial', 'dbeasyproducao', 'Setor', 'id', '{descricao}','ordem asc'  );
        $setorFinal = new TDBCombo('setorFinal', 'dbeasyproducao', 'Setor', 'id', '{descricao}','ordem asc'  );
        $produto = new TEntry('produto');

        $dataFinal->setMask('dd/mm/yyyy');
        $dataproducao->setMask('dd/mm/yyyy');

        $dataFinal->setDatabaseMask('yyyy-mm-dd');
        $dataproducao->setDatabaseMask('yyyy-mm-dd');

        $lote_id->setSize(100);
        $dataFinal->setSize(110);
        $produto->setSize('89%');
        $dataproducao->setSize(110);
        $setorFinal->setSize('70%');
        $setorInicial->setSize('70%');



        $row1 = $this->form->addFields([new TLabel('Lote:', null, '14px', null)],[$lote_id]);
        $row2 = $this->form->addFields([new TLabel('Data Inicial:', null, '14px', null)],[$dataproducao],[new TLabel('Data Final:', null, '14px', null)],[$dataFinal]);
        $row3 = $this->form->addFields([new TLabel('Setor Inicial:', null, '14px', null)],[$setorInicial],[new TLabel('Setor Final:', null, '14px', null)],[$setorFinal]);
        $row4 = $this->form->addFields([new TLabel('Produto:', null, '14px', null)],[$produto]);

        // keep the form filled during navigation with session data
        $this->form->setData( TSession::getValue(__CLASS__.'_filter_data') );

        $btn_ongeneratehtml = $this->form->addAction('Gerar HTML', new TAction([$this, 'onGenerateHtml']), 'fa:code #ffffff');
        $btn_ongeneratehtml->addStyleClass('btn-primary'); 

        $btn_ongeneratepdf = $this->form->addAction('Gerar PDF', new TAction([$this, 'onGeneratePdf']), 'fa:file-pdf-o #d44734');

        $btn_ongeneratertf = $this->form->addAction('Gerar RTF', new TAction([$this, 'onGenerateRtf']), 'fa:file-text-o #324bcc');

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        $container->add(TBreadCrumb::create(['Relatórios','Produtos a Separar Dia']));
        $container->add($this->form);

        parent::add($container);

    }

    public function onGenerateHtml($param = null) 
    {
        $this->onGenerate('html');
    }
    public function onGeneratePdf($param = null) 
    {
        $this->onGenerate('pdf');
    }
    public function onGenerateRtf($param = null) 
    {
        $this->onGenerate('rtf');
    }

    /**
     * Register the filter in the session
     */
    public function getFilters()
    {
        // get the search form data
        $data = $this->form->getData();

        $filters = [];

        TSession::setValue(__CLASS__.'_filter_data', NULL);
        TSession::setValue(__CLASS__.'_filters', NULL);

        if (isset($data->lote_id) AND ( (is_scalar($data->lote_id) AND $data->lote_id !== '') OR (is_array($data->lote_id) AND (!empty($data->lote_id)) )) )
        {

            $filters[] = new TFilter('lote_id', '=', $data->lote_id);// create the filter 
        }
        if (isset($data->dataproducao) AND ( (is_scalar($data->dataproducao) AND $data->dataproducao !== '') OR (is_array($data->dataproducao) AND (!empty($data->dataproducao)) )) )
        {

            $filters[] = new TFilter('dataproducao', '>=', $data->dataproducao);// create the filter 
        }
        if (isset($data->dataFinal) AND ( (is_scalar($data->dataFinal) AND $data->dataFinal !== '') OR (is_array($data->dataFinal) AND (!empty($data->dataFinal)) )) )
        {

            $filters[] = new TFilter('dataproducao', '<=', $data->dataFinal);// create the filter 
        }
        if (isset($data->setorInicial) AND ( (is_scalar($data->setorInicial) AND $data->setorInicial !== '') OR (is_array($data->setorInicial) AND (!empty($data->setorInicial)) )) )
        {

            $filters[] = new TFilter('setor_id', '>=', $data->setorInicial);// create the filter 
        }
        if (isset($data->setorFinal) AND ( (is_scalar($data->setorFinal) AND $data->setorFinal !== '') OR (is_array($data->setorFinal) AND (!empty($data->setorFinal)) )) )
        {

            $filters[] = new TFilter('setor_id', '<=', $data->setorFinal);// create the filter 
        }
        if (isset($data->produto) AND ( (is_scalar($data->produto) AND $data->produto !== '') OR (is_array($data->produto) AND (!empty($data->produto)) )) )
        {

            $filters[] = new TFilter('produto', 'like', "%{$data->produto}%");// create the filter 
        }

        // fill the form with data again
        $this->form->setData($data);

        // keep the search data in the session
        TSession::setValue(__CLASS__.'_filter_data', $data);

        return $filters;
    }

    public function onGenerate($format)
    {
        try
        {
            $filters = $this->getFilters();
            // open a transaction with database 'dbeasyproducao'
            TTransaction::open(self::$database);
            $param = [];
            // creates a repository for SeparaProdutosDia
            $repository = new TRepository(self::$activeRecord);
            // creates a criteria
            $criteria = new TCriteria;

            $param['order'] = 'dataproducao,ordem';
            $param['direction'] = 'asc';

            $criteria->setProperties($param);

            if ($filters)
            {
                foreach ($filters as $filter) 
                {
                    $criteria->add($filter);       
                }
            }

            // load the objects according to criteria
            $objects = $repository->load($criteria, FALSE);

            if ($objects)
            {
                $widths = array(250,500,250,80);

                switch ($format)
                {
                    case 'html':
                        $tr = new TTableWriterHTML($widths);
                        break;
                    case 'xls':
                        $tr = new TTableWriterXLS($widths);
                        break;
                    case 'pdf':
                        $tr = new TTableWriterPDF($widths, 'L');
                        break;
                    case 'rtf':
                        if (!class_exists('PHPRtfLite_Autoloader'))
                        {
                            PHPRtfLite::registerAutoloader();
                        }
                        $tr = new TTableWriterRTF($widths, 'L');
                        break;
                }

                if (!empty($tr))
                {
                    // create the document styles
                    $tr->addStyle('title',      'Helvetica', '10', 'B', '#000000', '#dbdbdb');
                    $tr->addStyle('datap',      'Arial',     '10', '',  '#333333', '#f7f7c7');
                    $tr->addStyle('datai',      'Arial',     '10', '',  '#333333', '#ffffff');
                    $tr->addStyle('header',     'Helvetica', '16', 'B', '#5a5a5a', '#6B6B6B');
                    $tr->addStyle('footer',     'Helvetica', '10', 'B', '#5a5a5a', '#A3A3A3');
                    $tr->addStyle('break',      'Helvetica', '10', 'B', '#03469e', '#e5f7d2');
                    $tr->addStyle('total',      'Helvetica', '10', 'I', '#000000', '#c7c7c7');
                    $tr->addStyle('breakTotal', 'Helvetica', '10', 'I', '#000000', '#c6c8d0');

                    $tr->addRow();
                    $tr->addCell('PRODUTOS A SEPARAR POR DIA / SETOR', 'center','title', 4);
                    $tr->addRow();

                    // add titles row
                    $tr->addRow();
                    $tr->addCell('Lote', 'left', 'title');
                    $tr->addCell('Produto', 'left', 'title');
                    $tr->addCell('Quantidade', 'right', 'title');
                    $tr->addCell('UN', 'center', 'title');

                    $grandTotal = [];
                    $breakTotal = [];
                    $breakValue = null;
                    $firstRow = true;

                    // controls the background filling
                    $colour = false;                
                    foreach ($objects as $object)
                    {
                        $style = $colour ? 'datap' : 'datai';

                        if ($object->dataproducao.$object->ordem !== $breakValue)
                        {
                            if (!$firstRow)
                            {
                                $tr->addRow();

                            }
                            $tr->addRow();
                            $aux    = $object->dataproducao;
                            $quebra = substr($aux, 8, 2) .'/'. substr($aux, 5, 2) .'/'. substr($aux, 0, 4).' - '.$object->setor; 
                            $tr->addCell($object->render($quebra), 'left', 'break', 4);
                            $breakTotal = [];
                        }
                        $breakValue = $object->dataproducao.$object->ordem;

                        $firstRow = false;

                        $object->qtde_produto = call_user_func(function($value, $object, $row) 
                        {
                            return number_format($value, 3, ',','.') ;

                        }, $object->qtde_produto, $object, null);

                        $tr->addRow();

                        $tr->addCell($object->lote_id, 'left', $style);
                        $tr->addCell($object->produto, 'left', $style);
                        $tr->addCell($object->qtde_produto, 'right', $style);
                        $tr->addCell($object->un, 'center', $style);

                        $colour = !$colour;
                    }

                    $tr->addRow();


                    $file = 'report_'.uniqid().".{$format}";
                    // stores the file
                    if (!file_exists("app/output/{$file}") || is_writable("app/output/{$file}"))
                    {
                        $tr->save("app/output/{$file}");
                    }
                    else
                    {
                        throw new Exception(_t('Permission denied') . ': ' . "app/output/{$file}");
                    }

                    parent::openFile("app/output/{$file}");

                    // shows the success message
                    new TMessage('info', _t('Report generated. Please, enable popups'));
                }
            }
            else
            {
                new TMessage('error', _t('No records found'));
            }

            // close the transaction
            TTransaction::close();
        }
        catch (Exception $e) // in case of exception
        {
            // shows the exception error message
            new TMessage('error', $e->getMessage());
            // undo all pending operations
            TTransaction::rollback();
        }
    }

    public function onShow($param = null)
    {

    }

}

