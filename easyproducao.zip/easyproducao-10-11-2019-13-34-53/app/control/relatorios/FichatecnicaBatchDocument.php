<?php

class FichatecnicaBatchDocument extends TPage
{
    private static $database = 'dbeasyproducao';
    private static $activeRecord = 'Fichatecnica';
    private static $primaryKey = 'id';
    private static $htmlFile = 'app/documents/FichatecnicaDocumentTemplate.html';
    private static $formName = 'formDocument_Fichatecnica';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct()
    {
        parent::__construct();

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);

        // define the form title
        $this->form->setFormTitle("Impressão de Ficha Técnica");

        $criteria_produto_id = new TCriteria();

        $filterVar = "S";
        $criteria_produto_id->add(new TFilter('final', '=', $filterVar)); 

        $id = new TEntry('id');
        $versao = new TEntry('versao');
        $produto_id = new TDBCombo('produto_id', 'dbeasyproducao', 'Produto', 'id', '{descricao}','descricao asc' , $criteria_produto_id );
        $rendimento = new TEntry('rendimento');
        $pesofinal = new TEntry('pesofinal');
        $created = new TDateTime('created');
        $modified = new TDateTime('modified');

        $created->setDatabaseMask('yyyy-mm-dd hh:ii');
        $modified->setDatabaseMask('yyyy-mm-dd hh:ii');

        $created->setMask('dd/mm/yyyy hh:ii');
        $modified->setMask('dd/mm/yyyy hh:ii');

        $id->setSize(92);
        $created->setSize(142);
        $versao->setSize('73%');
        $modified->setSize(142);
        $pesofinal->setSize('73%');
        $produto_id->setSize('70%');
        $rendimento->setSize('73%');

        $row1 = $this->form->addFields([new TLabel("Id:", null, '14px', null)],[$id],[new TLabel("Versão:", null, '14px', null)],[$versao]);
        $row2 = $this->form->addFields([new TLabel("Produto:", null, '14px', null)],[$produto_id]);
        $row3 = $this->form->addFields([new TLabel("Rendimento:", null, '14px', null)],[$rendimento],[new TLabel("Peso final:", null, '14px', null)],[$pesofinal]);
        $row4 = $this->form->addFields([new TLabel("Criado em:", null, '14px', null)],[$created],[new TLabel("Modificado em:", null, '14px', null)],[$modified]);

        // keep the form filled during navigation with session data
        $this->form->setData( TSession::getValue(__CLASS__.'_filter_data') );

        $btn_ongenerate = $this->form->addAction("Gerar", new TAction([$this, 'onGenerate']), 'fa:cog #ffffff');
        $btn_ongenerate->addStyleClass('btn-primary'); 

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        // $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        $container->add($this->form);

        parent::add($container);

    }

    public function onGenerate($param)
    {
        try 
        {
            TTransaction::open(self::$database);

            $data = $this->form->getData();
            $criteria = new TCriteria();

            if (isset($data->id) AND ( (is_scalar($data->id) AND $data->id !== '') OR (is_array($data->id) AND (!empty($data->id)) )) ) 
            {

                $criteria->add(new TFilter('id', '=', $data->id));
            }
            if (isset($data->versao) AND ( (is_scalar($data->versao) AND $data->versao !== '') OR (is_array($data->versao) AND (!empty($data->versao)) )) ) 
            {

                $criteria->add(new TFilter('versao', 'like', "%{$data->versao}%"));
            }
            if (isset($data->produto_id) AND ( (is_scalar($data->produto_id) AND $data->produto_id !== '') OR (is_array($data->produto_id) AND (!empty($data->produto_id)) )) ) 
            {

                $criteria->add(new TFilter('produto_id', '=', $data->produto_id));
            }
            if (isset($data->rendimento) AND ( (is_scalar($data->rendimento) AND $data->rendimento !== '') OR (is_array($data->rendimento) AND (!empty($data->rendimento)) )) ) 
            {

                $criteria->add(new TFilter('rendimento', '=', $data->rendimento));
            }
            if (isset($data->pesofinal) AND ( (is_scalar($data->pesofinal) AND $data->pesofinal !== '') OR (is_array($data->pesofinal) AND (!empty($data->pesofinal)) )) ) 
            {

                $criteria->add(new TFilter('pesofinal', 'like', "%{$data->pesofinal}%"));
            }
            if (isset($data->created) AND ( (is_scalar($data->created) AND $data->created !== '') OR (is_array($data->created) AND (!empty($data->created)) )) ) 
            {

                $criteria->add(new TFilter('created', '=', $data->created));
            }
            if (isset($data->modified) AND ( (is_scalar($data->modified) AND $data->modified !== '') OR (is_array($data->modified) AND (!empty($data->modified)) )) ) 
            {

                $criteria->add(new TFilter('modified', '=', $data->modified));
            }

            $objects = Fichatecnica::getObjects($criteria, FALSE);
            if ($objects)
            {
                $output = '';

                $count = 1;
                $count_records = count($objects);

                foreach ($objects as $object)
                {

                    $html = new AdiantiHTMLDocumentParser(self::$htmlFile);
                    $html->setMaster($object);

                    $objectsFichaitens_fichatecnica_id = Fichaitens::where('fichatecnica_id', '=', $object->id)->load();

                    $html->setDetail('Fichaitens.fichatecnica_id', $objectsFichaitens_fichatecnica_id);

                    $html->process();

                    if ($count < $count_records)
                    {
                        $html->addPageBreak();
                    }

                    $content = $html->getContents();
                    $dom = pQuery::parseStr($content);
                    $body = $dom->query('body');

                    if($body->count() > 0)
                    {
                        $output .= $body->html();    
                    }
                    else 
                    {
                        $output .= $content;    
                    }

                    $count ++;
                }

                $dom = pQuery::parseStr(file_get_contents(self::$htmlFile));
                $body = $dom->query('body');
                if($body->count() > 0)
                {
                    $body->html('<div>{$body}</div>');
                    $html = $dom->html();

                    $output = str_replace('<div>{$body}</div>', $output, $html);
                }

                $document = 'tmp/'.uniqid().'.pdf'; 
                $html = AdiantiHTMLDocumentParser::newFromString($output);
                $html->saveAsPDF($document, 'A4', 'portrait');

                parent::openFile($document);
                new TMessage('info', _t('Document successfully generated'));
            }
            else
            {
                new TMessage('info', _t('No records found'));   
            }

            TTransaction::close();

            TSession::setValue(__CLASS__.'_filter_data', $data);

            $this->form->setData($data);

        } 
        catch (Exception $e) 
        {
            // shows the exception error message
            new TMessage('error', $e->getMessage());

            // undo all pending operations
            TTransaction::rollback();
        }
    } 

    public function onShow($param = null)
    {

    }

}

