<?php

class FichatecnicaDocument extends TPage
{
    private static $database = 'dbeasyproducao';
    private static $activeRecord = 'Fichatecnica';
    private static $primaryKey = 'id';
    private static $htmlFile = 'app/documents/FichatecnicaDocumentTemplate.html';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {

    }

    public static function onGenerate($param)
    {
        try 
        {
            TTransaction::open(self::$database);

            $class = self::$activeRecord;
            $object = new $class($param['key']);

            $html = new AdiantiHTMLDocumentParser(self::$htmlFile);
            $html->setMaster($object);

            $objectsFichaitens_fichatecnica_id = Fichaitens::where('fichatecnica_id', '=', $param['key'])->load();
            $html->setDetail('Fichaitens.fichatecnica_id', $objectsFichaitens_fichatecnica_id);

            $html->process();

            $document = 'tmp/'.uniqid().'.pdf'; 
            $html->saveAsPDF($document, 'A4', 'portrait');

            TTransaction::close();

            parent::openFile($document);

            new TMessage('info', _t('Document successfully generated'));
        } 
        catch (Exception $e) 
        {
            // shows the exception error message
            new TMessage('error', $e->getMessage());

            // undo all pending operations
            TTransaction::rollback();
        }
    }

}

