<?php

class MovimentoproducaoReport extends TPage
{
    private $form; // form
    private $loaded;
    private static $database = 'dbeasyproducao';
    private static $activeRecord = 'Movimentoproducao';
    private static $primaryKey = 'id';
    private static $formName = 'formReport_Movimentoproducao';

    /**
     * Class constructor
     * Creates the page, the form and the listing
     */
    public function __construct()
    {
        parent::__construct();

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);

        // define the form title
        $this->form->setFormTitle("Relatório de Movimentos de Produção");

        $id = new TEntry('id');
        $datamovimento = new TDate('datamovimento');
        $tipomovimento_id = new TDBCombo('tipomovimento_id', 'dbeasyproducao', 'Tipomovimento', 'id', '{descricao}','descricao asc'  );
        $ordem_id = new TDBCombo('ordem_id', 'dbeasyproducao', 'Ordemproducao', 'id', '{id} {fichatecnica->produto->descricao} {dataproducao} ','id desc'  );
        $setor_id = new TDBCombo('setor_id', 'dbeasyproducao', 'Setor', 'id', '{descricao}','descricao asc'  );
        $ordem_loteitens_id = new TDBCombo('ordem_loteitens_id', 'dbeasyproducao', 'Loteitens', 'id', '{lote->id}','lote_id desc'  );

        $datamovimento->setDatabaseMask('yyyy-mm-dd');
        $datamovimento->setMask('dd/mm/yyyy');

        $id->setSize(92);
        $ordem_id->setSize('97%');
        $setor_id->setSize('75%');
        $datamovimento->setSize(92);
        $tipomovimento_id->setSize('75%');
        $ordem_loteitens_id->setSize('100%');

        $row1 = $this->form->addFields([new TLabel("Id:", null, '14px', null)],[$id],[new TLabel("Data:", null, '14px', null)],[$datamovimento]);
        $row2 = $this->form->addFields([new TLabel("Tipo movimento:", null, '14px', null)],[$tipomovimento_id],[new TLabel("Ordem:", null, '14px', null)],[$ordem_id]);
        $row3 = $this->form->addFields([new TLabel("Setor:", null, '14px', null)],[$setor_id],[new TLabel("Lote:", null, '14px', null)],[$ordem_loteitens_id]);

        // keep the form filled during navigation with session data
        $this->form->setData( TSession::getValue(__CLASS__.'_filter_data') );

        $btn_ongeneratehtml = $this->form->addAction("Gerar HTML", new TAction([$this, 'onGenerateHtml']), 'fa:code #ffffff');
        $btn_ongeneratehtml->addStyleClass('btn-primary'); 

        $btn_ongeneratepdf = $this->form->addAction("Gerar PDF", new TAction([$this, 'onGeneratePdf']), 'fa:file-pdf-o #d44734');

        $btn_ongeneratertf = $this->form->addAction("Gerar RTF", new TAction([$this, 'onGenerateRtf']), 'fa:file-text-o #324bcc');

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        $container->add(TBreadCrumb::create(["Relatórios","Movimentos Produção"]));
        $container->add($this->form);

        parent::add($container);

    }

    public function onGenerateHtml($param = null) 
    {
        $this->onGenerate('html');
    }
    public function onGeneratePdf($param = null) 
    {
        $this->onGenerate('pdf');
    }
    public function onGenerateRtf($param = null) 
    {
        $this->onGenerate('rtf');
    }

    /**
     * Register the filter in the session
     */
    public function getFilters()
    {
        // get the search form data
        $data = $this->form->getData();

        $filters = [];

        TSession::setValue(__CLASS__.'_filter_data', NULL);
        TSession::setValue(__CLASS__.'_filters', NULL);

        if (isset($data->id) AND ( (is_scalar($data->id) AND $data->id !== '') OR (is_array($data->id) AND (!empty($data->id)) )) )
        {

            $filters[] = new TFilter('id', '=', $data->id);// create the filter 
        }
        if (isset($data->datamovimento) AND ( (is_scalar($data->datamovimento) AND $data->datamovimento !== '') OR (is_array($data->datamovimento) AND (!empty($data->datamovimento)) )) )
        {

            $filters[] = new TFilter('datamovimento', '=', $data->datamovimento);// create the filter 
        }
        if (isset($data->tipomovimento_id) AND ( (is_scalar($data->tipomovimento_id) AND $data->tipomovimento_id !== '') OR (is_array($data->tipomovimento_id) AND (!empty($data->tipomovimento_id)) )) )
        {

            $filters[] = new TFilter('tipomovimento_id', '=', $data->tipomovimento_id);// create the filter 
        }
        if (isset($data->ordem_id) AND ( (is_scalar($data->ordem_id) AND $data->ordem_id !== '') OR (is_array($data->ordem_id) AND (!empty($data->ordem_id)) )) )
        {

            $filters[] = new TFilter('ordem_id', '=', $data->ordem_id);// create the filter 
        }
        if (isset($data->setor_id) AND ( (is_scalar($data->setor_id) AND $data->setor_id !== '') OR (is_array($data->setor_id) AND (!empty($data->setor_id)) )) )
        {

            $filters[] = new TFilter('setor_id', '=', $data->setor_id);// create the filter 
        }
        if (isset($data->ordem_loteitens_id) AND ( (is_scalar($data->ordem_loteitens_id) AND $data->ordem_loteitens_id !== '') OR (is_array($data->ordem_loteitens_id) AND (!empty($data->ordem_loteitens_id)) )) )
        {

            $filters[] = new TFilter('ordem_id', 'in', "(SELECT id FROM ordemproducao WHERE loteitens_id in (SELECT id FROM loteitens WHERE lote_id = '{$data->ordem_loteitens_id}'))");// create the filter 
        }

        // fill the form with data again
        $this->form->setData($data);

        // keep the search data in the session
        TSession::setValue(__CLASS__.'_filter_data', $data);

        return $filters;
    }

    public function onGenerate($format)
    {
        try
        {
            $filters = $this->getFilters();
            // open a transaction with database 'dbeasyproducao'
            TTransaction::open(self::$database);
            $param = [];
            // creates a repository for Movimentoproducao
            $repository = new TRepository(self::$activeRecord);
            // creates a criteria
            $criteria = new TCriteria;

            $param['order'] = 'setor_id,datamovimento';
            $param['direction'] = 'desc';

            $criteria->setProperties($param);

            if ($filters)
            {
                foreach ($filters as $filter) 
                {
                    $criteria->add($filter);       
                }
            }

            // load the objects according to criteria
            $objects = $repository->load($criteria, FALSE);

            if ($objects)
            {
                $widths = array(200,200,200,200,200,200);

                switch ($format)
                {
                    case 'html':
                        $tr = new TTableWriterHTML($widths);
                        break;
                    case 'xls':
                        $tr = new TTableWriterXLS($widths);
                        break;
                    case 'pdf':
                        $tr = new TTableWriterPDF($widths, 'L');
                        break;
                    case 'rtf':
                        if (!class_exists('PHPRtfLite_Autoloader'))
                        {
                            PHPRtfLite::registerAutoloader();
                        }
                        $tr = new TTableWriterRTF($widths, 'L');
                        break;
                }

                if (!empty($tr))
                {
                    // create the document styles
                    $tr->addStyle('title', 'Helvetica', '10', 'B',   '#000000', '#dbdbdb');
                    $tr->addStyle('datap', 'Arial', '10', '',    '#333333', '#f0f0f0');
                    $tr->addStyle('datai', 'Arial', '10', '',    '#333333', '#ffffff');
                    $tr->addStyle('header', 'Helvetica', '16', 'B',   '#5a5a5a', '#6B6B6B');
                    $tr->addStyle('footer', 'Helvetica', '10', 'B',  '#5a5a5a', '#A3A3A3');
                    $tr->addStyle('break', 'Helvetica', '10', 'B',  '#ffffff', '#9a9a9a');
                    $tr->addStyle('total', 'Helvetica', '10', 'I',  '#000000', '#c7c7c7');
                    $tr->addStyle('breakTotal', 'Helvetica', '10', 'I',  '#000000', '#c6c8d0');

                    $tr->addRow();
                    $tr->addCell('RELATÓRIO DE MOVIMENTOS DE PRODUÇÃO', 'center','title', 6);
                    $tr->addRow();

                    // add titles row
                    $tr->addRow();
                    $tr->addCell("Lote", 'right', 'title');
                    $tr->addCell("Id", 'right', 'title');
                    $tr->addCell("Data", 'center', 'title');
                    $tr->addCell("Tipo movimento", 'left', 'title');
                    $tr->addCell("Ordem", 'right', 'title');
                    $tr->addCell("Quantidade", 'right', 'title');

                    $grandTotal = [];
                    $breakTotal = [];
                    $breakValue = null;
                    $firstRow = true;

                    // controls the background filling
                    $colour = false;                
                    foreach ($objects as $object)
                    {
                        $style = $colour ? 'datap' : 'datai';

                        if ($object->setor_id !== $breakValue)
                        {
                            if (!$firstRow)
                            {
                                $tr->addRow();

                                $breakTotal_id = count($breakTotal['id']);

                                $tr->addCell('', 'center', 'breakTotal');
                                $tr->addCell($breakTotal_id, 'right', 'breakTotal');
                                $tr->addCell('', 'center', 'breakTotal');
                                $tr->addCell('', 'center', 'breakTotal');
                                $tr->addCell('', 'center', 'breakTotal');
                                $tr->addCell('', 'center', 'breakTotal');
                            }
                            $tr->addRow();
                            $tr->addCell($object->render('{setor->descricao}'), 'left', 'break', 6);
                            $breakTotal = [];
                        }
                        $breakValue = $object->setor_id;

                        $grandTotal['id'][] = $object->id;
                        $breakTotal['id'][] = $object->id;

                        $firstRow = false;

                        $object->datamovimento = call_user_func(function($value, $object, $row) 
                        {
                            if(!empty(trim($value)))
                            {
                                try
                                {
                                    $date = new DateTime($value);
                                    return $date->format('d/m/Y');
                                }
                                catch (Exception $e)
                                {
                                    return $value;
                                }
                            }
                        }, $object->datamovimento, $object, null);

                        $tr->addRow();

                        $tr->addCell($object->ordem->loteitens->lote_id, 'right', $style);
                        $tr->addCell($object->id, 'right', $style);
                        $tr->addCell($object->datamovimento, 'center', $style);
                        $tr->addCell($object->tipomovimento->descricao, 'left', $style);
                        $tr->addCell($object->ordem->fichatecnica_id, 'right', $style);
                        $tr->addCell($object->quantidade, 'right', $style);

                        $colour = !$colour;
                    }

                    $tr->addRow();

                    $tr->addRow();

                    $grandTotal_id = count($grandTotal['id']);

                    $tr->addCell('', 'center', 'total');
                    $tr->addCell($grandTotal_id, 'right', 'total');
                    $tr->addCell('', 'center', 'total');
                    $tr->addCell('', 'center', 'total');
                    $tr->addCell('', 'center', 'total');
                    $tr->addCell('', 'center', 'total');

                    $file = 'report_'.uniqid().".{$format}";
                    // stores the file
                    if (!file_exists("app/output/{$file}") || is_writable("app/output/{$file}"))
                    {
                        $tr->save("app/output/{$file}");
                    }
                    else
                    {
                        throw new Exception(_t('Permission denied') . ': ' . "app/output/{$file}");
                    }

                    parent::openFile("app/output/{$file}");

                    // shows the success message
                    new TMessage('info', _t('Report generated. Please, enable popups'));
                }
            }
            else
            {
                new TMessage('error', _t('No records found'));
            }

            // close the transaction
            TTransaction::close();
        }
        catch (Exception $e) // in case of exception
        {
            // shows the exception error message
            new TMessage('error', $e->getMessage());
            // undo all pending operations
            TTransaction::rollback();
        }
    }

    public function onShow($param = null)
    {

    }

}

