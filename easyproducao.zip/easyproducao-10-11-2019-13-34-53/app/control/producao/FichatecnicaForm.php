<?php

class FichatecnicaForm extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = 'dbeasyproducao';
    private static $activeRecord = 'Fichatecnica';
    private static $primaryKey = 'id';
    private static $formName = 'form_Fichatecnica';

    use Adianti\Base\AdiantiMasterDetailTrait;

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Ficha Técnica");


        $id = new TEntry('id');
        $tipo = new TCombo('tipo');
        $produto_id = new TDBCombo('produto_id', 'dbeasyproducao', 'Produto', 'id', '{descricao}','descricao asc'  );
        $dias = new TEntry('dias');
        $rendimento = new TEntry('rendimento');
        $unidade = new TEntry('unidade');
        $pesofinal = new TEntry('pesofinal');
        $created = new TDateTime('created');
        $modified = new TDateTime('modified');
        $fichaitens_fichatecnica_setor_id = new TDBCombo('fichaitens_fichatecnica_setor_id', 'dbeasyproducao', 'Setor', 'id', '{descricao}','descricao asc'  );
        $fichaitens_fichatecnica_produto_id = new TDBCombo('fichaitens_fichatecnica_produto_id', 'dbeasyproducao', 'Produto', 'id', '{descricao}','descricao asc'  );
        $fichaitens_fichatecnica_quantidade = new TNumeric('fichaitens_fichatecnica_quantidade', '3', ',', '.' );
        $fichaitens_fichatecnica_tempo = new TEntry('fichaitens_fichatecnica_tempo');
        $fichaitens_fichatecnica_observacao = new TEntry('fichaitens_fichatecnica_observacao');
        $fichaitens_fichatecnica_id = new THidden('fichaitens_fichatecnica_id');

        $tipo->setChangeAction(new TAction([$this,'ajustaUnidade']));

        $tipo->addValidation("Tipo", new TRequiredValidator()); 
        $produto_id->addValidation("Produto", new TRequiredValidator()); 
        $rendimento->addValidation("Rendimento", new TRequiredValidator()); 
        $created->addValidation("Criado em", new TRequiredValidator()); 
        $modified->addValidation("Modificado em", new TRequiredValidator()); 

        $tipo->addItems(['E'=>'Empanada','R'=>'Recheio']);
        $unidade->setMaxLength(20);
        $fichaitens_fichatecnica_tempo->setTip("Tempo padrão para execução em minutos");

        $created->setMask('dd/mm/yyyy hh:ii');
        $modified->setMask('dd/mm/yyyy hh:ii');

        $created->setDatabaseMask('yyyy-mm-dd hh:ii');
        $modified->setDatabaseMask('yyyy-mm-dd hh:ii');

        $id->setEditable(false);
        $unidade->setEditable(false);
        $created->setEditable(false);
        $modified->setEditable(false);

        $tipo->setValue('E');
        $unidade->setValue('Empanada');
        $created->setValue(date('d/m/Y hh:ii'));
        $modified->setValue(date('d/m/Y hh:ii'));

        $id->setSize(92);
        $tipo->setSize('70%');
        $dias->setSize('70%');
        $created->setSize(142);
        $modified->setSize(134);
        $unidade->setSize('49%');
        $pesofinal->setSize('73%');
        $rendimento->setSize('49%');
        $produto_id->setSize('100%');
        $fichaitens_fichatecnica_tempo->setSize('70%');
        $fichaitens_fichatecnica_setor_id->setSize('70%');
        $fichaitens_fichatecnica_produto_id->setSize('70%');
        $fichaitens_fichatecnica_quantidade->setSize('70%');
        $fichaitens_fichatecnica_observacao->setSize('70%');

        $row1 = $this->form->addFields([new TLabel("Id:", null, '14px', null)],[$id],[new TLabel("Tipo:", '#ff0000', '14px', null)],[$tipo]);
        $row2 = $this->form->addFields([new TLabel("Produto:", '#ff0000', '14px', null)],[$produto_id],[new TLabel("Dias Antecipação", null, '14px', null)],[$dias]);
        $row3 = $this->form->addFields([new TLabel("Rendimento:", '#ff0000', '14px', null)],[$rendimento,$unidade],[new TLabel("Peso final:", null, '14px', null)],[$pesofinal]);
        $row4 = $this->form->addFields([new TLabel("Criado em:", '#ff0000', '14px', null)],[$created],[new TLabel("Modificado em:", '#ff0000', '14px', null)],[$modified]);
        $row5 = $this->form->addContent([new TFormSeparator("Itens", '#333333', '18', '#eeeeee')]);
        $row6 = $this->form->addFields([new TLabel("Setor:", '#ff0000', '14px', null)],[$fichaitens_fichatecnica_setor_id]);
        $row7 = $this->form->addFields([new TLabel("Produto:", '#ff0000', '14px', null)],[$fichaitens_fichatecnica_produto_id]);
        $row8 = $this->form->addFields([new TLabel("Quantidade:", '#ff0000', '14px', null)],[$fichaitens_fichatecnica_quantidade],[new TLabel("Tempo em minutos:", null, '14px', null)],[$fichaitens_fichatecnica_tempo]);
        $row9 = $this->form->addFields([new TLabel("Observação:", null, '14px', null)],[$fichaitens_fichatecnica_observacao]);
        $row10 = $this->form->addFields([$fichaitens_fichatecnica_id]);         
        $add_fichaitens_fichatecnica = new TButton('add_fichaitens_fichatecnica');

        $action_fichaitens_fichatecnica = new TAction(array($this, 'onAddFichaitensFichatecnica'));

        $add_fichaitens_fichatecnica->setAction($action_fichaitens_fichatecnica, "Adicionar");
        $add_fichaitens_fichatecnica->setImage('fa:plus #000000');

        $this->form->addFields([$add_fichaitens_fichatecnica]);

        $this->fichaitens_fichatecnica_list = new BootstrapDatagridWrapper(new TQuickGrid);
        $this->fichaitens_fichatecnica_list->style = 'width:100%';
        $this->fichaitens_fichatecnica_list->class .= ' table-bordered';
        $this->fichaitens_fichatecnica_list->disableDefaultClick();
        $this->fichaitens_fichatecnica_list->addQuickColumn('', 'edit', 'left', 50);
        $this->fichaitens_fichatecnica_list->addQuickColumn('', 'delete', 'left', 50);

        $column_fichaitens_fichatecnica_setor_id = $this->fichaitens_fichatecnica_list->addQuickColumn("Setor", 'fichaitens_fichatecnica_setor_id', 'left');
        $column_fichaitens_fichatecnica_produto_id = $this->fichaitens_fichatecnica_list->addQuickColumn("Produto", 'fichaitens_fichatecnica_produto_id', 'left');
        $column_fichaitens_fichatecnica_quantidade = $this->fichaitens_fichatecnica_list->addQuickColumn("Quantidade", 'fichaitens_fichatecnica_quantidade', 'left');
        $column_fichaitens_fichatecnica_tempo = $this->fichaitens_fichatecnica_list->addQuickColumn("Tempo", 'fichaitens_fichatecnica_tempo', 'left');
        $column_fichaitens_fichatecnica_observacao = $this->fichaitens_fichatecnica_list->addQuickColumn("Observação", 'fichaitens_fichatecnica_observacao', 'left');

        $this->fichaitens_fichatecnica_list->createModel();
        $this->form->addContent([$this->fichaitens_fichatecnica_list]);

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fa:floppy-o #ffffff');
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fa:eraser #dd5a43');

        $btn_onshow = $this->form->addAction("Retornar", new TAction(['FichatecnicaList', 'onShow']), 'fa:arrow-circle-left #0988bf');

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        // $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        $container->add($this->form);

        parent::add($container);

    }

    public static function ajustaUnidade($param = null) 
    {
        try 
        {
            // Código gerado pelo snippet: "Exibir mensagem"
            // -----

            // Código gerado pelo snippet: "Enviar dados para campo"
            $object = new stdClass();

            $txt = 'Em empanadas';
            if ( $param['tipo'] == 'R' ) {
                $txt = 'Em peso     ';       
            }

            $object->unidade = $txt;
            //$object->fieldName = 'insira o novo valor aqui'; //sample

            TForm::sendData(self::$formName, $object);
            // -----

            //code here

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            /**
            // Enable Debug logger for SQL operations inside the transaction
            TTransaction::setLogger(new TLoggerSTD); // standard output
            TTransaction::setLogger(new TLoggerTXT('log.txt')); // file
            **/

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Fichatecnica(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            // se não tiver id é um registro novo então devemos salvar a data de inserção do registro
            if(!$object->id) 
            {
                $object->created = date('Y-m-d H:i:s');
            }
            // sempre salvamos a data de atualização do registro
            $object->modified = date('Y-m-d H:i:s');

            $object->store(); // save the object 

            $this->fireEvents($object);

            $messageAction = new TAction(['FichatecnicaList', 'onShow']);   

            $fichaitens_fichatecnica_items = $this->storeItems('Fichaitens', 'fichatecnica_id', $object, 'fichaitens_fichatecnica', function($masterObject, $detailObject){ 

                //code here

            }); 

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            /**
            // To define an action to be executed on the message close event:
            $messageAction = new TAction(['className', 'methodName']);
            **/

            new TMessage('info', AdiantiCoreTranslator::translate('Record saved'), $messageAction);

        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Fichatecnica($key); // instantiates the Active Record 

                $fichaitens_fichatecnica_items = $this->loadItems('Fichaitens', 'fichatecnica_id', $object, 'fichaitens_fichatecnica', function($masterObject, $detailObject, $objectItems){ 

                    //code here

                }); 

                $this->form->setData($object); // fill the form 

                    $this->fireEvents($object);
                    $this->onReload();

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

        TSession::setValue('fichaitens_fichatecnica_items', null);

        $this->onReload();
    }

    public function onAddFichaitensFichatecnica( $param )
    {
        try
        {
            $data = $this->form->getData();

            if(!$data->fichaitens_fichatecnica_setor_id)
            {
                throw new Exception(AdiantiCoreTranslator::translate('The field ^1 is required', "Setor"));
            }             
            if(!$data->fichaitens_fichatecnica_produto_id)
            {
                throw new Exception(AdiantiCoreTranslator::translate('The field ^1 is required', "Produto"));
            }             
            if(!$data->fichaitens_fichatecnica_quantidade)
            {
                throw new Exception(AdiantiCoreTranslator::translate('The field ^1 is required', "Quantidade"));
            }             

            $fichaitens_fichatecnica_items = TSession::getValue('fichaitens_fichatecnica_items');
            $key = isset($data->fichaitens_fichatecnica_id) && $data->fichaitens_fichatecnica_id ? $data->fichaitens_fichatecnica_id : uniqid();
            $fields = []; 

            $fields['fichaitens_fichatecnica_setor_id'] = $data->fichaitens_fichatecnica_setor_id;
            $fields['fichaitens_fichatecnica_produto_id'] = $data->fichaitens_fichatecnica_produto_id;
            $fields['fichaitens_fichatecnica_quantidade'] = $data->fichaitens_fichatecnica_quantidade;
            $fields['fichaitens_fichatecnica_tempo'] = $data->fichaitens_fichatecnica_tempo;
            $fields['fichaitens_fichatecnica_observacao'] = $data->fichaitens_fichatecnica_observacao;
            $fichaitens_fichatecnica_items[ $key ] = $fields;

            TSession::setValue('fichaitens_fichatecnica_items', $fichaitens_fichatecnica_items);

            $data->fichaitens_fichatecnica_id = '';
            $data->fichaitens_fichatecnica_setor_id = '';
            $data->fichaitens_fichatecnica_produto_id = '';
            $data->fichaitens_fichatecnica_quantidade = '';
            $data->fichaitens_fichatecnica_tempo = '';
            $data->fichaitens_fichatecnica_observacao = '';

            $this->form->setData($data);
            $this->fireEvents($data);
            $this->onReload( $param );
        }
        catch (Exception $e)
        {
            $this->form->setData( $this->form->getData());
            $this->fireEvents($data);
            new TMessage('error', $e->getMessage());
        }
    }

    public function onEditFichaitensFichatecnica( $param )
    {
        $data = $this->form->getData();

        // read session items
        $items = TSession::getValue('fichaitens_fichatecnica_items');

        // get the session item
        $item = $items[$param['fichaitens_fichatecnica_id_row_id']];

        $data->fichaitens_fichatecnica_setor_id = $item['fichaitens_fichatecnica_setor_id'];
        $data->fichaitens_fichatecnica_produto_id = $item['fichaitens_fichatecnica_produto_id'];
        $data->fichaitens_fichatecnica_quantidade = $item['fichaitens_fichatecnica_quantidade'];
        $data->fichaitens_fichatecnica_tempo = $item['fichaitens_fichatecnica_tempo'];
        $data->fichaitens_fichatecnica_observacao = $item['fichaitens_fichatecnica_observacao'];

        $data->fichaitens_fichatecnica_id = $param['fichaitens_fichatecnica_id_row_id'];

        // fill product fields
        $this->form->setData( $data );

        $this->fireEvents($data);

        $this->onReload( $param );

    }

    public function onDeleteFichaitensFichatecnica( $param )
    {
        $data = $this->form->getData();

        $data->fichaitens_fichatecnica_setor_id = '';
        $data->fichaitens_fichatecnica_produto_id = '';
        $data->fichaitens_fichatecnica_quantidade = '';
        $data->fichaitens_fichatecnica_tempo = '';
        $data->fichaitens_fichatecnica_observacao = '';

        // clear form data
        $this->form->setData( $data );

        // read session items
        $items = TSession::getValue('fichaitens_fichatecnica_items');

        // delete the item from session
        unset($items[$param['fichaitens_fichatecnica_id_row_id']]);
        TSession::setValue('fichaitens_fichatecnica_items', $items);

        $this->fireEvents($data);

        // reload sale items
        $this->onReload( $param );

    }

    public function onReloadFichaitensFichatecnica( $param )
    {
        $items = TSession::getValue('fichaitens_fichatecnica_items'); 

        $this->fichaitens_fichatecnica_list->clear(); 

        if($items) 
        { 
            $cont = 1; 
            foreach ($items as $key => $item) 
            {
                $rowItem = new StdClass;

                $action_del = new TAction(array($this, 'onDeleteFichaitensFichatecnica')); 
                $action_del->setParameter('fichaitens_fichatecnica_id_row_id', $key);
                $action_del->setParameter('row_data', base64_encode(serialize($item)));
                $action_del->setParameter('key', $key);

                $action_edi = new TAction(array($this, 'onEditFichaitensFichatecnica'));  
                $action_edi->setParameter('fichaitens_fichatecnica_id_row_id', $key);  
                $action_edi->setParameter('row_data', base64_encode(serialize($item)));
                $action_edi->setParameter('key', $key);

                $button_del = new TButton('delete_fichaitens_fichatecnica'.$cont);
                $button_del->setAction($action_del, '');
                $button_del->setFormName($this->form->getName());
                $button_del->class = 'btn btn-link btn-sm';
                $button_del->title = "Excluir";
                $button_del->setImage('fa:trash-o #dd5a43');

                $rowItem->delete = $button_del;

                $button_edi = new TButton('edit_fichaitens_fichatecnica'.$cont);
                $button_edi->setAction($action_edi, '');
                $button_edi->setFormName($this->form->getName());
                $button_edi->class = 'btn btn-link btn-sm';
                $button_edi->title = "Editar";
                $button_edi->setImage('fa:pencil-square-o #478fca');

                $rowItem->edit = $button_edi;

                $rowItem->fichaitens_fichatecnica_setor_id = '';
                if(isset($item['fichaitens_fichatecnica_setor_id']) && $item['fichaitens_fichatecnica_setor_id'])
                {
                    TTransaction::open('dbeasyproducao');
                    $setor = Setor::find($item['fichaitens_fichatecnica_setor_id']);
                    if($setor)
                    {
                        $rowItem->fichaitens_fichatecnica_setor_id = $setor->render('{descricao}');
                    }
                    TTransaction::close();
                }

                $rowItem->fichaitens_fichatecnica_produto_id = '';
                if(isset($item['fichaitens_fichatecnica_produto_id']) && $item['fichaitens_fichatecnica_produto_id'])
                {
                    TTransaction::open('dbeasyproducao');
                    $produto = Produto::find($item['fichaitens_fichatecnica_produto_id']);
                    if($produto)
                    {
                        $rowItem->fichaitens_fichatecnica_produto_id = $produto->render('{descricao}');
                    }
                    TTransaction::close();
                }

                $rowItem->fichaitens_fichatecnica_quantidade = isset($item['fichaitens_fichatecnica_quantidade']) ? $item['fichaitens_fichatecnica_quantidade'] : '';
                $rowItem->fichaitens_fichatecnica_tempo = isset($item['fichaitens_fichatecnica_tempo']) ? $item['fichaitens_fichatecnica_tempo'] : '';
                $rowItem->fichaitens_fichatecnica_observacao = isset($item['fichaitens_fichatecnica_observacao']) ? $item['fichaitens_fichatecnica_observacao'] : '';

                $row = $this->fichaitens_fichatecnica_list->addItem($rowItem);

                $cont++;
            } 
        } 
    } 

    public function onShow($param = null)
    {
        TSession::setValue('fichaitens_fichatecnica_items', null);

        $this->onReload();

    } 

    public function fireEvents( $object )
    {
        $obj = new stdClass;
        if(is_object($object) && get_class($object) == 'stdClass')
        {
            if(isset($object->tipo))
            {
                $obj->tipo = $object->tipo;
            }
            if(isset($object->unidade))
            {
                $obj->unidade = $object->unidade;
            }
        }
        elseif(is_object($object))
        {
            if(isset($object->tipo))
            {
                $obj->tipo = $object->tipo;
            }
            if(isset($object->unidade))
            {
                $obj->unidade = $object->unidade;
            }
        }
        TForm::sendData(self::$formName, $obj);
    }  

    public function onReload($params = null)
    {
        $this->loaded = TRUE;

        $this->onReloadFichaitensFichatecnica($params);
    }

    public function show() 
    { 
        if (!$this->loaded AND (!isset($_GET['method']) OR $_GET['method'] !== 'onReload') ) 
        { 
            $this->onReload( func_get_arg(0) );
        }
        parent::show();
    }

}

