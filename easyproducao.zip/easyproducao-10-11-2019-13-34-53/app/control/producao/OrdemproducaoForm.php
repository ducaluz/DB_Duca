<?php

class OrdemproducaoForm extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = 'dbeasyproducao';
    private static $activeRecord = 'Ordemproducao';
    private static $primaryKey = 'id';
    private static $formName = 'form_Ordemproducao';

    use Adianti\Base\AdiantiMasterDetailTrait;

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de Ordem Produção");


        $id = new TEntry('id');
        $dataproducao = new TDate('dataproducao');
        $fichatecnica_id = new TDBCombo('fichatecnica_id', 'dbeasyproducao', 'Fichatecnica', 'id', '{produto->descricao}','id asc'  );
        $loteitens_id = new TDBCombo('loteitens_id', 'dbeasyproducao', 'Loteitens', 'id', '{lote_id} - {id} ','fichatecnica_id asc'  );
        $quantidade = new TEntry('quantidade');
        $status = new TCombo('status');
        $movimentoproducao_ordem_datamovimento = new TDate('movimentoproducao_ordem_datamovimento');
        $movimentoproducao_ordem_tipomovimento_id = new TDBCombo('movimentoproducao_ordem_tipomovimento_id', 'dbeasyproducao', 'Tipomovimento', 'id', '{descricao}','descricao asc'  );
        $movimentoproducao_ordem_setor_id = new TDBCombo('movimentoproducao_ordem_setor_id', 'dbeasyproducao', 'Setor', 'id', '{descricao}','descricao asc'  );
        $movimentoproducao_ordem_quantidade = new TEntry('movimentoproducao_ordem_quantidade');
        $movimentoproducao_ordem_id = new THidden('movimentoproducao_ordem_id');

        $dataproducao->addValidation("Data", new TRequiredValidator()); 
        $fichatecnica_id->addValidation("Ficha técnica", new TRequiredValidator()); 
        $quantidade->addValidation("Quantidade", new TRequiredValidator()); 
        $status->addValidation("Estado", new TRequiredValidator()); 

        $status->addItems(['1'=>'Programado','2'=>'Pre preparo','3'=>'Recheio','4'=>'Producao','5'=>'Embalagem','6'=>'Expedicao']);

        $id->setEditable(false);
        $loteitens_id->setEditable(false);

        $dataproducao->setMask('dd/mm/yyyy');
        $movimentoproducao_ordem_datamovimento->setMask('dd/mm/yyyy');

        $dataproducao->setDatabaseMask('yyyy-mm-dd');
        $movimentoproducao_ordem_datamovimento->setDatabaseMask('yyyy-mm-dd');

        $id->setSize(91.5039);
        $status->setSize('85%');
        $quantidade->setSize('75%');
        $dataproducao->setSize('85%');
        $loteitens_id->setSize('85%');
        $fichatecnica_id->setSize('97%');
        $movimentoproducao_ordem_setor_id->setSize('89%');
        $movimentoproducao_ordem_quantidade->setSize('94%');
        $movimentoproducao_ordem_datamovimento->setSize('85%');
        $movimentoproducao_ordem_tipomovimento_id->setSize('94%');

        $this->form->appendPage("Ordem Produção");

        $this->form->addFields([new THidden('current_tab')]);
        $this->form->setTabFunction("$('[name=current_tab]').val($(this).attr('data-current_page'));");

        $row1 = $this->form->addFields([new TLabel("Id:", null, '14px', null)],[$id],[new TLabel("Data:", '#ff0000', '14px', null)],[$dataproducao]);
        $row2 = $this->form->addFields([new TLabel("Ficha técnica:", '#ff0000', '14px', null)],[$fichatecnica_id],[new TLabel("Lote - Item lote:", null, '14px', null)],[$loteitens_id]);
        $row3 = $this->form->addFields([new TLabel("Quantidade:", '#ff0000', '14px', null)],[$quantidade],[new TLabel("Estado:", '#ff0000', '14px', null)],[$status]);

        $this->form->appendPage("Movimentos");
        $row4 = $this->form->addContent([new TFormSeparator("Movimentos de produção", '#333333', '18', '#eeeeee')]);
        $row5 = $this->form->addFields([new TLabel("Data:", '#ff0000', '14px', null)],[$movimentoproducao_ordem_datamovimento],[new TLabel("Tipo movimento:", '#ff0000', '14px', null)],[$movimentoproducao_ordem_tipomovimento_id]);
        $row6 = $this->form->addFields([new TLabel("Setor:", '#ff0000', '14px', null)],[$movimentoproducao_ordem_setor_id],[new TLabel("Quantidade:", '#ff0000', '14px', null)],[$movimentoproducao_ordem_quantidade]);
        $row7 = $this->form->addFields([$movimentoproducao_ordem_id]);         
        $add_movimentoproducao_ordem = new TButton('add_movimentoproducao_ordem');

        $action_movimentoproducao_ordem = new TAction(array($this, 'onAddMovimentoproducaoOrdem'));

        $add_movimentoproducao_ordem->setAction($action_movimentoproducao_ordem, "Adicionar");
        $add_movimentoproducao_ordem->setImage('fa:plus #000000');

        $this->form->addFields([$add_movimentoproducao_ordem]);

        $this->movimentoproducao_ordem_list = new BootstrapDatagridWrapper(new TQuickGrid);
        $this->movimentoproducao_ordem_list->style = 'width:100%';
        $this->movimentoproducao_ordem_list->class .= ' table-bordered';
        $this->movimentoproducao_ordem_list->disableDefaultClick();
        $this->movimentoproducao_ordem_list->addQuickColumn('', 'edit', 'left', 50);
        $this->movimentoproducao_ordem_list->addQuickColumn('', 'delete', 'left', 50);

        $column_movimentoproducao_ordem_datamovimento_transformed = $this->movimentoproducao_ordem_list->addQuickColumn("Data", 'movimentoproducao_ordem_datamovimento', 'left');
        $column_movimentoproducao_ordem_tipomovimento_id = $this->movimentoproducao_ordem_list->addQuickColumn("Tipo movimento", 'movimentoproducao_ordem_tipomovimento_id', 'left');
        $column_movimentoproducao_ordem_setor_id = $this->movimentoproducao_ordem_list->addQuickColumn("Setor", 'movimentoproducao_ordem_setor_id', 'left');
        $column_movimentoproducao_ordem_quantidade = $this->movimentoproducao_ordem_list->addQuickColumn("Quantidade", 'movimentoproducao_ordem_quantidade', 'left');

        $this->movimentoproducao_ordem_list->createModel();
        $this->form->addContent([$this->movimentoproducao_ordem_list]);

        $column_movimentoproducao_ordem_datamovimento_transformed->setTransformer(function($value, $object, $row) 
        {
            if(!empty(trim($value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fa:floppy-o #ffffff');
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fa:eraser #dd5a43');

        $btn_onshow = $this->form->addAction("Retornar", new TAction(['OrdemproducaoList', 'onShow']), 'fa:arrow-circle-left #0988fb');

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        // $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        $container->add($this->form);

        parent::add($container);

    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            /**
            // Enable Debug logger for SQL operations inside the transaction
            TTransaction::setLogger(new TLoggerSTD); // standard output
            TTransaction::setLogger(new TLoggerTXT('log.txt')); // file
            **/

            $messageAction = null;

            throw new Exception("ATENÇÃO!!!. Inclusão e modificação somente a tela de lotes.") ;

            // Início do bloco comentado para inclusao nos lotes
            /* 
            $this->form->validate(); // validate form data

            $object = new Ordemproducao(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            // valida capacidade
            $txtCapacidade = '';
            if ($data->id != '') 
            {
                $idOp = $data->id;
            }else
            {
                $idOp = 0;
            }
            $tem = 0;
            $conection = TTransaction::get();
            $query = $conection->prepare("select * from valida_capacidade(?, ?, ?, ?)");   
            $query->execute(array($data->fichatecnica_id, $data->dataproducao, $data->quantidade, $idOp));
            $result = $query->fetchAll();

            // analisa os resultados
            foreach ($result as $row) 
            { 
                if (isset($row['valida_capacidade']) && $row['valida_capacidade'] != 0 )
                {
                    $tem = $row['valida_capacidade'] ;
                }
            } 

            if ( $tem < 0) 
            {
                //$txtCapacidade = "Capacidade de produção estrapolada para este dia em: ".$tem ;
                throw new Exception("Capacidade de produção estrapolada para este dia em: ".$tem) ;
            }else
            {
                $txtCapacidade = "Capacidade de produção livre para este dia em: ".$tem ;
            }

            // fim do valida capacidade

            $object->store(); // save the object 

            $movimentoproducao_ordem_items = $this->storeItems('Movimentoproducao', 'ordem_id', $object, 'movimentoproducao_ordem', function($masterObject, $detailObject){ 

                //code here

            }); 

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            // To define an action to be executed on the message close event:
            // $messageAction = new TAction(['className', 'methodName']);

            $message = AdiantiCoreTranslator::translate('Record saved') . '<br>' . '<br>';
            $message.= $txtCapacidade . '<br>';

            new TMessage('info', $message, $messageAction);

            */  //fim do bloco comentado para inclusao nos lotes

        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Ordemproducao($key); // instantiates the Active Record 

                $movimentoproducao_ordem_items = $this->loadItems('Movimentoproducao', 'ordem_id', $object, 'movimentoproducao_ordem', function($masterObject, $detailObject, $objectItems){ 

                    //code here

                }); 

                $this->form->setData($object); // fill the form 

                    $this->onReload();

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

        TSession::setValue('movimentoproducao_ordem_items', null);

        $this->onReload();
    }

    public function onAddMovimentoproducaoOrdem( $param )
    {
        try
        {
            $data = $this->form->getData();

            if(!$data->movimentoproducao_ordem_datamovimento)
            {
                throw new Exception(AdiantiCoreTranslator::translate('The field ^1 is required', "Data"));
            }             
            if(!$data->movimentoproducao_ordem_tipomovimento_id)
            {
                throw new Exception(AdiantiCoreTranslator::translate('The field ^1 is required', "Tipo movimento"));
            }             
            if(!$data->movimentoproducao_ordem_setor_id)
            {
                throw new Exception(AdiantiCoreTranslator::translate('The field ^1 is required', "Setor"));
            }             
            if(!$data->movimentoproducao_ordem_quantidade)
            {
                throw new Exception(AdiantiCoreTranslator::translate('The field ^1 is required', "Quantidade"));
            }             

            $movimentoproducao_ordem_items = TSession::getValue('movimentoproducao_ordem_items');
            $key = isset($data->movimentoproducao_ordem_id) && $data->movimentoproducao_ordem_id ? $data->movimentoproducao_ordem_id : uniqid();
            $fields = []; 

            $fields['movimentoproducao_ordem_datamovimento'] = $data->movimentoproducao_ordem_datamovimento;
            $fields['movimentoproducao_ordem_tipomovimento_id'] = $data->movimentoproducao_ordem_tipomovimento_id;
            $fields['movimentoproducao_ordem_setor_id'] = $data->movimentoproducao_ordem_setor_id;
            $fields['movimentoproducao_ordem_quantidade'] = $data->movimentoproducao_ordem_quantidade;
            $movimentoproducao_ordem_items[ $key ] = $fields;

            TSession::setValue('movimentoproducao_ordem_items', $movimentoproducao_ordem_items);

            $data->movimentoproducao_ordem_id = '';
            $data->movimentoproducao_ordem_datamovimento = '';
            $data->movimentoproducao_ordem_tipomovimento_id = '';
            $data->movimentoproducao_ordem_setor_id = '';
            $data->movimentoproducao_ordem_quantidade = '';

            $this->form->setData($data);

            $this->onReload( $param );
        }
        catch (Exception $e)
        {
            $this->form->setData( $this->form->getData());

            new TMessage('error', $e->getMessage());
        }
    }

    public function onEditMovimentoproducaoOrdem( $param )
    {
        $data = $this->form->getData();

        // read session items
        $items = TSession::getValue('movimentoproducao_ordem_items');

        // get the session item
        $item = $items[$param['movimentoproducao_ordem_id_row_id']];

        $data->movimentoproducao_ordem_datamovimento = $item['movimentoproducao_ordem_datamovimento'];
        $data->movimentoproducao_ordem_tipomovimento_id = $item['movimentoproducao_ordem_tipomovimento_id'];
        $data->movimentoproducao_ordem_setor_id = $item['movimentoproducao_ordem_setor_id'];
        $data->movimentoproducao_ordem_quantidade = $item['movimentoproducao_ordem_quantidade'];

        $data->movimentoproducao_ordem_id = $param['movimentoproducao_ordem_id_row_id'];

        // fill product fields
        $this->form->setData( $data );

        $this->onReload( $param );

    }

    public function onDeleteMovimentoproducaoOrdem( $param )
    {
        $data = $this->form->getData();

        $data->movimentoproducao_ordem_datamovimento = '';
        $data->movimentoproducao_ordem_tipomovimento_id = '';
        $data->movimentoproducao_ordem_setor_id = '';
        $data->movimentoproducao_ordem_quantidade = '';

        // clear form data
        $this->form->setData( $data );

        // read session items
        $items = TSession::getValue('movimentoproducao_ordem_items');

        // delete the item from session
        unset($items[$param['movimentoproducao_ordem_id_row_id']]);
        TSession::setValue('movimentoproducao_ordem_items', $items);

        // reload sale items
        $this->onReload( $param );

    }

    public function onReloadMovimentoproducaoOrdem( $param )
    {
        $items = TSession::getValue('movimentoproducao_ordem_items'); 

        $this->movimentoproducao_ordem_list->clear(); 

        if($items) 
        { 
            $cont = 1; 
            foreach ($items as $key => $item) 
            {
                $rowItem = new StdClass;

                $action_del = new TAction(array($this, 'onDeleteMovimentoproducaoOrdem')); 
                $action_del->setParameter('movimentoproducao_ordem_id_row_id', $key);
                $action_del->setParameter('row_data', base64_encode(serialize($item)));
                $action_del->setParameter('key', $key);

                $action_edi = new TAction(array($this, 'onEditMovimentoproducaoOrdem'));  
                $action_edi->setParameter('movimentoproducao_ordem_id_row_id', $key);  
                $action_edi->setParameter('row_data', base64_encode(serialize($item)));
                $action_edi->setParameter('key', $key);

                $button_del = new TButton('delete_movimentoproducao_ordem'.$cont);
                $button_del->setAction($action_del, '');
                $button_del->setFormName($this->form->getName());
                $button_del->class = 'btn btn-link btn-sm';
                $button_del->title = "Excluir";
                $button_del->setImage('fa:trash-o #dd5a43');

                $rowItem->delete = $button_del;

                $button_edi = new TButton('edit_movimentoproducao_ordem'.$cont);
                $button_edi->setAction($action_edi, '');
                $button_edi->setFormName($this->form->getName());
                $button_edi->class = 'btn btn-link btn-sm';
                $button_edi->title = "Editar";
                $button_edi->setImage('fa:pencil-square-o #478fca');

                $rowItem->edit = $button_edi;

                $rowItem->movimentoproducao_ordem_datamovimento = isset($item['movimentoproducao_ordem_datamovimento']) ? $item['movimentoproducao_ordem_datamovimento'] : '';
                $rowItem->movimentoproducao_ordem_tipomovimento_id = '';
                if(isset($item['movimentoproducao_ordem_tipomovimento_id']) && $item['movimentoproducao_ordem_tipomovimento_id'])
                {
                    TTransaction::open('dbeasyproducao');
                    $tipomovimento = Tipomovimento::find($item['movimentoproducao_ordem_tipomovimento_id']);
                    if($tipomovimento)
                    {
                        $rowItem->movimentoproducao_ordem_tipomovimento_id = $tipomovimento->render('{descricao}');
                    }
                    TTransaction::close();
                }

                $rowItem->movimentoproducao_ordem_setor_id = '';
                if(isset($item['movimentoproducao_ordem_setor_id']) && $item['movimentoproducao_ordem_setor_id'])
                {
                    TTransaction::open('dbeasyproducao');
                    $setor = Setor::find($item['movimentoproducao_ordem_setor_id']);
                    if($setor)
                    {
                        $rowItem->movimentoproducao_ordem_setor_id = $setor->render('{descricao}');
                    }
                    TTransaction::close();
                }

                $rowItem->movimentoproducao_ordem_quantidade = isset($item['movimentoproducao_ordem_quantidade']) ? $item['movimentoproducao_ordem_quantidade'] : '';

                $row = $this->movimentoproducao_ordem_list->addItem($rowItem);

                $cont++;
            } 
        } 
    } 

    public function onShow($param = null)
    {
        TSession::setValue('movimentoproducao_ordem_items', null);

        $this->onReload();

    } 

    public function onReload($params = null)
    {
        $this->loaded = TRUE;

        $this->onReloadMovimentoproducaoOrdem($params);
    }

    public function show() 
    { 
        $param = func_get_arg(0);
        if(!empty($param['current_tab']))
        {
            $this->form->setCurrentPage($param['current_tab']);
        }

        if (!$this->loaded AND (!isset($_GET['method']) OR $_GET['method'] !== 'onReload') ) 
        { 
            $this->onReload( func_get_arg(0) );
        }
        parent::show();
    }

}

