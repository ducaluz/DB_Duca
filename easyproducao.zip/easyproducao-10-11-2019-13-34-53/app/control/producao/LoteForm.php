<?php

class LoteForm extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = 'dbeasyproducao';
    private static $activeRecord = 'Lote';
    private static $primaryKey = 'id';
    private static $formName = 'form_Lote';

    use Adianti\Base\AdiantiMasterDetailTrait;

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de lote");


        $id = new TEntry('id');
        $datalote = new TDate('datalote');
        $semana = new TEntry('semana');
        $codigo = new TEntry('codigo');
        $loteitens_lote_fichatecnica_id = new TDBCombo('loteitens_lote_fichatecnica_id', 'dbeasyproducao', 'Fichatecnica', 'id', '{id} -{produto->descricao} ','id asc'  );
        $loteitens_lote_quantidade = new TEntry('loteitens_lote_quantidade');
        $loteitens_lote_setor_id = new TDBCombo('loteitens_lote_setor_id', 'dbeasyproducao', 'Setor', 'id', '{descricao}','descricao asc'  );
        $loteitens_lote_id = new THidden('loteitens_lote_id');

        $datalote->setExitAction(new TAction([$this,'calculaSemana']));
        $loteitens_lote_quantidade->setExitAction(new TAction([$this,'validaCapacidade']));

        $datalote->addValidation("Data", new TRequiredValidator()); 

        $datalote->setMask('dd/mm/yyyy');
        $datalote->setDatabaseMask('yyyy-mm-dd');

        $id->setEditable(false);
        $semana->setEditable(false);

        $id->setSize(100);
        $semana->setSize('30%');
        $codigo->setSize('50%');
        $datalote->setSize('51%');
        $loteitens_lote_setor_id->setSize('70%');
        $loteitens_lote_quantidade->setSize('70%');
        $loteitens_lote_fichatecnica_id->setSize('70%');

        $row1 = $this->form->addFields([new TLabel("Id:", null, '14px', null)],[$id]);
        $row2 = $this->form->addFields([new TLabel("Data e Semana:", '#ff0000', '14px', null)],[$datalote,$semana]);
        $row3 = $this->form->addFields([new TLabel("Código Lote:", null, '14px', null)],[$codigo]);
        $row4 = $this->form->addContent([new TFormSeparator("Itens (ficha tecnica)", '#333333', '18', '#eeeeee')]);
        $row5 = $this->form->addFields([new TLabel("Ficha Técnica:", '#ff0000', '14px', null)],[$loteitens_lote_fichatecnica_id]);
        $row6 = $this->form->addFields([new TLabel("Quantidade:", '#ff0000', '14px', null)],[$loteitens_lote_quantidade]);
        $row7 = $this->form->addFields([new TLabel("Setor Final:", '#ff0000', '14px', null)],[$loteitens_lote_setor_id]);
        $row8 = $this->form->addFields([$loteitens_lote_id]);         
        $add_loteitens_lote = new TButton('add_loteitens_lote');

        $action_loteitens_lote = new TAction(array($this, 'onAddLoteitensLote'));

        $add_loteitens_lote->setAction($action_loteitens_lote, "Adicionar");
        $add_loteitens_lote->setImage('fa:plus #000000');

        $this->form->addFields([$add_loteitens_lote]);

        $this->loteitens_lote_list = new BootstrapDatagridWrapper(new TQuickGrid);
        $this->loteitens_lote_list->style = 'width:100%';
        $this->loteitens_lote_list->class .= ' table-bordered';
        $this->loteitens_lote_list->disableDefaultClick();
        $this->loteitens_lote_list->addQuickColumn('', 'edit', 'left', 50);
        $this->loteitens_lote_list->addQuickColumn('', 'delete', 'left', 50);

        $column_loteitens_lote_fichatecnica_id = $this->loteitens_lote_list->addQuickColumn("Ficha Técnica", 'loteitens_lote_fichatecnica_id', 'left');
        $column_loteitens_lote_quantidade = $this->loteitens_lote_list->addQuickColumn("Quantidade", 'loteitens_lote_quantidade', 'left');
        $column_loteitens_lote_setor_id = $this->loteitens_lote_list->addQuickColumn("Setor Final", 'loteitens_lote_setor_id', 'left');

        $this->loteitens_lote_list->createModel();
        $this->form->addContent([$this->loteitens_lote_list]);

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fa:floppy-o #ffffff');
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fa:eraser #dd5a43');

        $btn_onshow = $this->form->addAction("Retornar", new TAction(['LoteList', 'onShow']), 'fa:arrow-circle-left #0988fb');

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        // $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        $container->add($this->form);

        parent::add($container);

    }

    public static function calculaSemana($param = null) 
    {
        try 
        {
            //code here

            //verifica se é maior igual a hoje
            $hoje = date('Ymd'); 

            $dtpa = substr($param['datalote'], 6, 4);
            $dtpa = $dtpa.substr($param['datalote'], 3, 2);
            $dtpa = $dtpa.substr($param['datalote'], 0, 2); 

            if (isset($param['datalote']) && !empty($param['datalote']) && $dtpa < $hoje) {
                throw new Exception("Data inválida. Não é possível programar para o passado.") ;                
            }

            //se data igual a hoje, avisar sobre recheios
            if (isset($param['datalote']) && !empty($param['datalote']) && $dtpa == $hoje ) {
                new TMessage('info', 'Atenção!!!. Se HOUVER(EM) recheio(s), com informação de dias de antecipação maior do que zero (0), o(s) recheio(s) será(ão) programados para HOJE.') ;                
            }

            //calcula semana
            $var = 0;
            $dia = substr($param['datalote'], 0, 2);
            $mes = substr($param['datalote'], 3, 2);
            $ano = substr($param['datalote'], 6, 4);

            if ($dia<>'  ') 
            {
                $var=intval( date('z', mktime(0,0,0, intval($mes), intval($dia), intval($ano) ) ) / 7 ) + 1;

                // verifica se eh segunda
                /*
                $nomeDia = date('l', mktime(0,0,0, intval($mes), intval($dia), intval($ano) ) );
                if ( $nomeDia <> 'Monday') 
                {
                    throw new Exception("Data inválida. Somente segunda-feira é aceito.") ;
                }
                */
            }

            // Código gerado pelo snippet: "Enviar dados para campo"
            $object = new stdClass();
            $object->semana = $var;
            //$object->fieldName = 'insira o novo valor aqui'; //sample

            TForm::sendData(self::$formName, $object);

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function validaCapacidade($param = null) 
    {
        try 
        {
            //code here
            // inicio valida capacidade
            $txtCapacidade = '';
            $idItem = intval($param['loteitens_lote_id']);
            $tem = 0;
            TTransaction::open(self::$database); // open a transaction
            $conection = TTransaction::get();
            $query = $conection->prepare("select * from valida_capacidade(?, ?, ?, ?)");   
            $query->execute(array($param['loteitens_lote_fichatecnica_id'], $param['datalote'], $param['loteitens_lote_quantidade'], $idItem));
            $result = $query->fetchAll();

            // analisa os resultados
            foreach ($result as $row) 
            { 
                if (isset($row['valida_capacidade']) && $row['valida_capacidade'] != 0 )
                {
                    $tem = $row['valida_capacidade'] ;
                }
            } 

            if ( $tem < 0) 
            {
                //$txtCapacidade = "Capacidade de produção estrapolada para este dia em: ".$tem ;
                throw new Exception("Capacidade de produção estrapolada para este dia em: ".$tem) ;
            }else
            {
                $txtCapacidade = "Capacidade de produção livre para este dia em: ".$tem ;
            }

            // fim do valida capacidade

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            /**
            // Enable Debug logger for SQL operations inside the transaction
            TTransaction::setLogger(new TLoggerSTD); // standard output
            TTransaction::setLogger(new TLoggerTXT('log.txt')); // file
            **/

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Lote(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $object->store(); // save the object 

            $loteitens_lote_items = $this->storeItems('Loteitens', 'lote_id', $object, 'loteitens_lote', function($masterObject, $detailObject){ 

                //code here

            }); 

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            /**
            // To define an action to be executed on the message close event:
            $messageAction = new TAction(['className', 'methodName']);
            **/

            new TMessage('info', AdiantiCoreTranslator::translate('Record saved'), $messageAction);

        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Lote($key); // instantiates the Active Record 

                $loteitens_lote_items = $this->loadItems('Loteitens', 'lote_id', $object, 'loteitens_lote', function($masterObject, $detailObject, $objectItems){ 

                    //code here

                }); 

                $this->form->setData($object); // fill the form 

                    $this->onReload();

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

        TSession::setValue('loteitens_lote_items', null);

        $this->onReload();
    }

    public function onAddLoteitensLote( $param )
    {
        try
        {
            $data = $this->form->getData();

            if(!$data->loteitens_lote_fichatecnica_id)
            {
                throw new Exception(AdiantiCoreTranslator::translate('The field ^1 is required', "Fichatecnica id"));
            }             
            if(!$data->loteitens_lote_quantidade)
            {
                throw new Exception(AdiantiCoreTranslator::translate('The field ^1 is required', "Quantidade"));
            }             
            if(!$data->loteitens_lote_setor_id)
            {
                throw new Exception(AdiantiCoreTranslator::translate('The field ^1 is required', "Setor id"));
            }             

            $loteitens_lote_items = TSession::getValue('loteitens_lote_items');
            $key = isset($data->loteitens_lote_id) && $data->loteitens_lote_id ? $data->loteitens_lote_id : uniqid();
            $fields = []; 

            $fields['loteitens_lote_fichatecnica_id'] = $data->loteitens_lote_fichatecnica_id;
            $fields['loteitens_lote_quantidade'] = $data->loteitens_lote_quantidade;
            $fields['loteitens_lote_setor_id'] = $data->loteitens_lote_setor_id;
            $loteitens_lote_items[ $key ] = $fields;

            TSession::setValue('loteitens_lote_items', $loteitens_lote_items);

            $data->loteitens_lote_id = '';
            $data->loteitens_lote_fichatecnica_id = '';
            $data->loteitens_lote_quantidade = '';
            $data->loteitens_lote_setor_id = '';

            $this->form->setData($data);

            $this->onReload( $param );
        }
        catch (Exception $e)
        {
            $this->form->setData( $this->form->getData());

            new TMessage('error', $e->getMessage());
        }
    }

    public function onEditLoteitensLote( $param )
    {
        $data = $this->form->getData();

        // read session items
        $items = TSession::getValue('loteitens_lote_items');

        // get the session item
        $item = $items[$param['loteitens_lote_id_row_id']];

        $data->loteitens_lote_fichatecnica_id = $item['loteitens_lote_fichatecnica_id'];
        $data->loteitens_lote_quantidade = $item['loteitens_lote_quantidade'];
        $data->loteitens_lote_setor_id = $item['loteitens_lote_setor_id'];

        $data->loteitens_lote_id = $param['loteitens_lote_id_row_id'];

        // fill product fields
        $this->form->setData( $data );

        $this->onReload( $param );

    }

    public function onDeleteLoteitensLote( $param )
    {
        $data = $this->form->getData();

        $data->loteitens_lote_fichatecnica_id = '';
        $data->loteitens_lote_quantidade = '';
        $data->loteitens_lote_setor_id = '';

        // clear form data
        $this->form->setData( $data );

        // read session items
        $items = TSession::getValue('loteitens_lote_items');

        // delete the item from session
        unset($items[$param['loteitens_lote_id_row_id']]);
        TSession::setValue('loteitens_lote_items', $items);

        // reload sale items
        $this->onReload( $param );

    }

    public function onReloadLoteitensLote( $param )
    {
        $items = TSession::getValue('loteitens_lote_items'); 

        $this->loteitens_lote_list->clear(); 

        if($items) 
        { 
            $cont = 1; 
            foreach ($items as $key => $item) 
            {
                $rowItem = new StdClass;

                $action_del = new TAction(array($this, 'onDeleteLoteitensLote')); 
                $action_del->setParameter('loteitens_lote_id_row_id', $key);
                $action_del->setParameter('row_data', base64_encode(serialize($item)));
                $action_del->setParameter('key', $key);

                $action_edi = new TAction(array($this, 'onEditLoteitensLote'));  
                $action_edi->setParameter('loteitens_lote_id_row_id', $key);  
                $action_edi->setParameter('row_data', base64_encode(serialize($item)));
                $action_edi->setParameter('key', $key);

                $button_del = new TButton('delete_loteitens_lote'.$cont);
                $button_del->setAction($action_del, '');
                $button_del->setFormName($this->form->getName());
                $button_del->class = 'btn btn-link btn-sm';
                $button_del->title = "Excluir";
                $button_del->setImage('fa:trash-o #dd5a43');

                $rowItem->delete = $button_del;

                $button_edi = new TButton('edit_loteitens_lote'.$cont);
                $button_edi->setAction($action_edi, '');
                $button_edi->setFormName($this->form->getName());
                $button_edi->class = 'btn btn-link btn-sm';
                $button_edi->title = "Editar";
                $button_edi->setImage('fa:pencil-square-o #478fca');

                $rowItem->edit = $button_edi;

                $rowItem->loteitens_lote_fichatecnica_id = '';
                if(isset($item['loteitens_lote_fichatecnica_id']) && $item['loteitens_lote_fichatecnica_id'])
                {
                    TTransaction::open('dbeasyproducao');
                    $fichatecnica = Fichatecnica::find($item['loteitens_lote_fichatecnica_id']);
                    if($fichatecnica)
                    {
                        $rowItem->loteitens_lote_fichatecnica_id = $fichatecnica->render('{id} -{produto->descricao} ');
                    }
                    TTransaction::close();
                }

                $rowItem->loteitens_lote_quantidade = isset($item['loteitens_lote_quantidade']) ? $item['loteitens_lote_quantidade'] : '';
                $rowItem->loteitens_lote_setor_id = '';
                if(isset($item['loteitens_lote_setor_id']) && $item['loteitens_lote_setor_id'])
                {
                    TTransaction::open('dbeasyproducao');
                    $setor = Setor::find($item['loteitens_lote_setor_id']);
                    if($setor)
                    {
                        $rowItem->loteitens_lote_setor_id = $setor->render('{descricao}');
                    }
                    TTransaction::close();
                }

                $row = $this->loteitens_lote_list->addItem($rowItem);

                $cont++;
            } 
        } 
    } 

    public function onShow($param = null)
    {
        TSession::setValue('loteitens_lote_items', null);

        $this->onReload();

    } 

    public function onReload($params = null)
    {
        $this->loaded = TRUE;

        $this->onReloadLoteitensLote($params);
    }

    public function show() 
    { 
        if (!$this->loaded AND (!isset($_GET['method']) OR $_GET['method'] !== 'onReload') ) 
        { 
            $this->onReload( func_get_arg(0) );
        }
        parent::show();
    }

    public static function onYes($param = null) 
    {
        try 
        {
            //code here

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public static function onNo($param = null) 
    {
        try 
        {
            //code here
        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

}

