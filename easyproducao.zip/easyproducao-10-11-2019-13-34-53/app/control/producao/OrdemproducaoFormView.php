<?php

class OrdemproducaoFormView extends TPage
{
    protected $form; // form
    private static $database = 'dbeasyproducao';
    private static $activeRecord = 'Ordemproducao';
    private static $primaryKey = 'id';
    private static $formName = 'formView_Ordemproducao';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        TTransaction::open(self::$database);
        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);

        $ordemproducao = new Ordemproducao($param['key']);
        // define the form title
        $this->form->setFormTitle("Ordem de Produção");

        $label1 = new TLabel("Id:", '#333333', '12px', '');
        $text1 = new TTextDisplay($ordemproducao->id, '#333333', '12px', '');
        $label2 = new TLabel("Data:", '#333333', '12px', '');
        $text2 = new TTextDisplay(TDate::convertToMask($ordemproducao->dataproducao, 'yyyy-mm-dd', 'dd/mm/yyyy'), '#333333', '12px', '');
        $label3 = new TLabel("Quantidade:", '#333333', '12px', '');
        $text3 = new TTextDisplay($ordemproducao->quantidade, '#333333', '12px', '');
        $label4 = new TLabel("Estado:", '#333333', '12px', '');
        $text4 = new TTextDisplay($ordemproducao->status, '#333333', '12px', '');
        $label5 = new TLabel("Ficha técnica:", '#333333', '12px', '');
        $text5 = new TTextDisplay($ordemproducao->fichatecnica->produto->descricao, '#333333', '12px', '');
        $label6 = new TLabel("Lote - Item lote:", '#333333', '12px', '');
        $text6 = new TTextDisplay($ordemproducao->loteitens->lote_id, '#333333', '12px', '');

        $row1 = $this->form->addFields([$label1],[$text1],[$label2],[$text2]);
        $row2 = $this->form->addFields([$label3],[$text3],[$label4],[$text4]);
        $row3 = $this->form->addFields([$label5],[$text5],[$label6],[$text6]);

        $this->movimentoproducao_ordem_id_list = new TQuickGrid;
        $this->movimentoproducao_ordem_id_list->style = 'width:100%';
        $this->movimentoproducao_ordem_id_list->disableDefaultClick();

        $column_datamovimento_transformed = $this->movimentoproducao_ordem_id_list->addQuickColumn("Data", 'datamovimento', 'left');
        $column_tipomovimento_descricao = $this->movimentoproducao_ordem_id_list->addQuickColumn("Tipo movimento", 'tipomovimento->descricao', 'left');
        $column_setor_descricao = $this->movimentoproducao_ordem_id_list->addQuickColumn("Setor", 'setor->descricao', 'left');
        $column_quantidade = $this->movimentoproducao_ordem_id_list->addQuickColumn("Quantidade", 'quantidade', 'left');

        $column_datamovimento_transformed->setTransformer(function($value, $object, $row) 
        {
            if(!empty(trim($value)))
            {
                try
                {
                    $date = new DateTime($value);
                    return $date->format('d/m/Y');
                }
                catch (Exception $e)
                {
                    return $value;
                }
            }
        });

        $this->movimentoproducao_ordem_id_list->createModel();

        $criteria_movimentoproducao_ordem_id = new TCriteria();
        $criteria_movimentoproducao_ordem_id->add(new TFilter('ordem_id', '=', $ordemproducao->id));

        $criteria_movimentoproducao_ordem_id->setProperty('order', 'id desc');

        $movimentoproducao_ordem_id_items = Movimentoproducao::getObjects($criteria_movimentoproducao_ordem_id);

        $this->movimentoproducao_ordem_id_list->addItems($movimentoproducao_ordem_id_items);

        $icon = new TImage('fa:circle-o #000000');
        $title = new TTextDisplay("{$icon} Movimentos de Produção:", '#333333', '12px', '');

        $panel = new TPanelGroup($title, '#f5f5f5');
        $panel->class = 'panel panel-default formView-detail';
        $panel->add(new BootstrapDatagridWrapper($this->movimentoproducao_ordem_id_list));

        $this->form->addContent([$panel]);

        // create the form actions
        $btnLabel = new TLabel("Retornar");
        $btnLabel->setFontSize('12px'); 
        $btnLabel->setFontColor('#333333'); 

        $btn = $this->form->addHeaderAction($btnLabel, new TAction(['OrdemproducaoList', 'onShow']), 'fa:arrow-circle-left #0988bf'); 

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        // $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        $container->add($this->form);

        TTransaction::close();
        parent::add($container);

    }

    public function onShow($param = null)
    {     

    }

}

