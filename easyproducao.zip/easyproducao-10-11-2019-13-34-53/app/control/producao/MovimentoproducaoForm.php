<?php

class MovimentoproducaoForm extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = 'dbeasyproducao';
    private static $activeRecord = 'Movimentoproducao';
    private static $primaryKey = 'id';
    private static $formName = 'form_Movimentoproducao';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de movimentos de produção");


        $id = new TEntry('id');
        $datamovimento = new TDate('datamovimento');
        $tipomovimento_id = new TDBCombo('tipomovimento_id', 'dbeasyproducao', 'Tipomovimento', 'id', '{descricao}','descricao asc'  );
        $ordem_id = new TDBCombo('ordem_id', 'dbeasyproducao', 'Ordemproducao', 'id', ' {id} - {fichatecnica->produto->descricao} - {dataproducao}','dataproducao desc'  );
        $setor_id = new TDBCombo('setor_id', 'dbeasyproducao', 'Setor', 'id', '{descricao}','descricao asc'  );
        $quantidade = new TEntry('quantidade');

        $datamovimento->addValidation("Data", new TRequiredValidator()); 
        $tipomovimento_id->addValidation("Tipo movimento", new TRequiredValidator()); 
        $ordem_id->addValidation("Ordem", new TRequiredValidator()); 
        $setor_id->addValidation("Setor", new TRequiredValidator()); 
        $quantidade->addValidation("Quantidade", new TRequiredValidator()); 

        $datamovimento->setMask('dd/mm/yyyy');
        $id->setEditable(false);
        $datamovimento->setDatabaseMask('yyyy-mm-dd');

        $id->setSize(150);
        $ordem_id->setSize('70%');
        $setor_id->setSize('70%');
        $quantidade->setSize('70%');
        $datamovimento->setSize(150);
        $tipomovimento_id->setSize('70%');

        $row1 = $this->form->addFields([new TLabel("Id:", null, '14px', null)],[$id]);
        $row2 = $this->form->addFields([new TLabel("Data:", '#ff0000', '14px', null)],[$datamovimento]);
        $row3 = $this->form->addFields([new TLabel("Tipo movimento:", '#ff0000', '14px', null)],[$tipomovimento_id]);
        $row4 = $this->form->addFields([new TLabel("Ordem:", '#ff0000', '14px', null)],[$ordem_id]);
        $row5 = $this->form->addFields([new TLabel("Setor:", '#ff0000', '14px', null)],[$setor_id]);
        $row6 = $this->form->addFields([new TLabel("Quantidade:", '#ff0000', '14px', null)],[$quantidade]);

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fa:floppy-o #ffffff');
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fa:eraser #dd5a43');

        $btn_onshow = $this->form->addAction("Retornar", new TAction(['MovimentoproducaoList', 'onShow']), 'fa:arrow-circle-left #0988bf');

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        // $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        $container->add($this->form);

        parent::add($container);

    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            /**
            // Enable Debug logger for SQL operations inside the transaction
            TTransaction::setLogger(new TLoggerSTD); // standard output
            TTransaction::setLogger(new TLoggerTXT('log.txt')); // file
            **/

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Movimentoproducao(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $object->store(); // save the object 

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            // atualiza status
            $statusEditado = '1';
            If ($data->setor_id == 1) {
                $statusEditado = '2';  // pre preparo
            }elseif ($data->setor_id == 2) {
                $statusEditado = '3';  // Recheio 
            }elseif ($data->setor_id >= 3 && $data->setor_id < 8 ) {
                $statusEditado = '4';  //- Produção
            }elseif ($data->setor_id == 8) {
                $statusEditado = '5';  // - Embalagem
            }elseif ($data->setor_id >= 9) {
                $statusEditado = '6';  //- Expedição
            }
            $conection = TTransaction::get();
            $query = $conection->prepare("update ordemproducao set status = ? where id = ?");   
            $query->execute(array($statusEditado, $data->ordem_id));
            $result = $query->fetchAll();
            // fim do atualiza status            

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            /**
            // To define an action to be executed on the message close event:
            $messageAction = new TAction(['className', 'methodName']);
            **/

            new TMessage('info', AdiantiCoreTranslator::translate('Record saved'), $messageAction);

        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Movimentoproducao($key); // instantiates the Active Record 

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

    } 

}

