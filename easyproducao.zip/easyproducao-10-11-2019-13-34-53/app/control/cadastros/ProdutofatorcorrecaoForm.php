<?php

class ProdutofatorcorrecaoForm extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = 'dbeasyproducao';
    private static $activeRecord = 'Produtofatorcorrecao';
    private static $primaryKey = 'id';
    private static $formName = 'form_Produtofatorcorrecao';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de Fator de Correção");

        $criteria_produto_id = new TCriteria();

        $id = new TEntry('id');
        $datafator = new TDate('datafator');
        $produto_id = new TDBUniqueSearch('produto_id', 'dbeasyproducao', 'Produto', 'id', 'descricao','id asc' , $criteria_produto_id );
        $fator = new TNumeric('fator', '3', ',', '.' );

        $datafator->addValidation("Datafator", new TRequiredValidator()); 
        $produto_id->addValidation("Produto id", new TRequiredValidator()); 
        $fator->addValidation("Fator", new TRequiredValidator()); 

        $id->setEditable(false);
        $datafator->setDatabaseMask('yyyy-mm-dd');
        $produto_id->setMinLength(2);

        $datafator->setMask('dd/mm/yyyy');
        $produto_id->setMask('{descricao}');

        $id->setSize(150);
        $fator->setSize(150);
        $datafator->setSize(150);
        $produto_id->setSize('90%');

        $row1 = $this->form->addFields([new TLabel("Id:", null, '14px', null)],[$id]);
        $row2 = $this->form->addFields([new TLabel("Data fator:", '#ff0000', '14px', null)],[$datafator]);
        $row3 = $this->form->addFields([new TLabel("Produto:", '#ff0000', '14px', null)],[$produto_id]);
        $row4 = $this->form->addFields([new TLabel("Fator:", '#ff0000', '14px', null)],[$fator]);

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fa:floppy-o #ffffff');
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fa:eraser #dd5a43');

        $btn_onshow = $this->form->addAction("Retorna", new TAction(['ProdutofatorcorrecaoList', 'onShow']), 'fa:arrow-circle-left #0988fb');

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        // $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        $container->add($this->form);

        parent::add($container);

    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            /**
            // Enable Debug logger for SQL operations inside the transaction
            TTransaction::setLogger(new TLoggerSTD); // standard output
            TTransaction::setLogger(new TLoggerTXT('log.txt')); // file
            **/

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Produtofatorcorrecao(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $object->store(); // save the object 

            $messageAction = new TAction(['ProdutofatorcorrecaoList', 'onShow']);   

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            /**
            // To define an action to be executed on the message close event:
            $messageAction = new TAction(['className', 'methodName']);
            **/

            new TMessage('info', AdiantiCoreTranslator::translate('Record saved'), $messageAction);

        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Produtofatorcorrecao($key); // instantiates the Active Record 

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

    } 

}

