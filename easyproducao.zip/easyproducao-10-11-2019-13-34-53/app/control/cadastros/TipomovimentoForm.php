<?php

class TipomovimentoForm extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = 'dbeasyproducao';
    private static $activeRecord = 'Tipomovimento';
    private static $primaryKey = 'id';
    private static $formName = 'form_Tipomovimento';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de Tipo de Movimento");


        $id = new TEntry('id');
        $descricao = new TEntry('descricao');
        $entradasaida = new TRadioGroup('entradasaida');
        $created = new TDateTime('created');
        $modified = new TDateTime('modified');

        $descricao->addValidation("Descricao", new TRequiredValidator()); 
        $created->addValidation("Created", new TRequiredValidator()); 
        $modified->addValidation("Modified", new TRequiredValidator()); 

        $entradasaida->addItems(['E'=>'Entrada','S'=>'Saída']);
        $entradasaida->setLayout('horizontal');
        $entradasaida->setBreakItems(2);

        $created->setMask('dd/mm/yyyy hh:ii');
        $modified->setMask('dd/mm/yyyy hh:ii');

        $created->setDatabaseMask('yyyy-mm-dd hh:ii');
        $modified->setDatabaseMask('yyyy-mm-dd hh:ii');

        $id->setEditable(false);
        $created->setEditable(false);
        $modified->setEditable(false);

        $entradasaida->setValue('E');
        $created->setValue(date('d/m/Y h:i'));
        $modified->setValue(date('d/m/Y h:i'));

        $id->setSize(100);
        $created->setSize('80%');
        $modified->setSize('80%');
        $descricao->setSize('72%');
        $entradasaida->setSize(80);

        $row1 = $this->form->addFields([new TLabel("Id:", null, '14px', null)],[$id]);
        $row2 = $this->form->addFields([new TLabel("Descrição:", '#ff0000', '14px', null)],[$descricao],[new TLabel("Entrada/Saída:", '#ff0000', '14px', null)],[$entradasaida]);
        $row3 = $this->form->addFields([new TLabel("Criado em:", '#ff0000', '14px', null)],[$created],[new TLabel("Modificado em:", '#ff0000', '14px', null)],[$modified]);

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fa:floppy-o #ffffff');
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fa:eraser #dd5a43');

        $btn_onshow = $this->form->addAction("Retornar", new TAction(['TipomovimentoList', 'onShow']), 'fa:arrow-circle-left #0988bf');

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        // $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        $container->add($this->form);

        parent::add($container);

    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            /**
            // Enable Debug logger for SQL operations inside the transaction
            TTransaction::setLogger(new TLoggerSTD); // standard output
            TTransaction::setLogger(new TLoggerTXT('log.txt')); // file
            **/

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Tipomovimento(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            // se não tiver id é um registro novo então devemos salvar a data de inserção do registro
            if(!$object->id) 
            {
                $object->created = date('Y-m-d H:i:s');
            }
            // sempre salvamos a data de atualização do registro
            $object->modified = date('Y-m-d H:i:s');

            $object->store(); // save the object 

            $messageAction = new TAction(['TipomovimentoList', 'onShow']);   

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            /**
            // To define an action to be executed on the message close event:
            $messageAction = new TAction(['className', 'methodName']);
            **/

            new TMessage('info', AdiantiCoreTranslator::translate('Record saved'), $messageAction);

        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Tipomovimento($key); // instantiates the Active Record 

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

    } 

}

