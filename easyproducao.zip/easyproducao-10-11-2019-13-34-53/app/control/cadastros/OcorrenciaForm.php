<?php

class OcorrenciaForm extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = 'dbeasyproducao';
    private static $activeRecord = 'Ocorrencia';
    private static $primaryKey = 'id';
    private static $formName = 'form_Ocorrencia';

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de Ocorrência");


        $id = new TEntry('id');
        $dataocorrencia = new TDate('dataocorrencia');
        $datainicio = new TDateTime('datainicio');
        $datafinal = new TDateTime('datafinal');
        $setor_id = new TDBUniqueSearch('setor_id', 'dbeasyproducao', 'Setor', 'id', 'descricao','descricao asc'  );
        $tipomovimento_id = new TDBUniqueSearch('tipomovimento_id', 'dbeasyproducao', 'Tipomovimento', 'id', 'descricao','descricao asc'  );
        $descricao = new TText('descricao');
        $executor = new TEntry('executor');
        $cep = new TEntry('cep');
        $logradouro = new TEntry('logradouro');
        $complemento = new TEntry('complemento');
        $localidade = new TEntry('localidade');
        $bairro = new TEntry('bairro');
        $uf = new TEntry('uf');
        $ibge = new TEntry('ibge');

        $dataocorrencia->addValidation("Dataocorrencia", new TRequiredValidator()); 
        $datainicio->addValidation("Datainicio", new TRequiredValidator()); 
        $datafinal->addValidation("Datafinal", new TRequiredValidator()); 
        $descricao->addValidation("Descricao", new TRequiredValidator()); 
        $executor->addValidation("Executor", new TRequiredValidator()); 

        $id->setEditable(false);

        $setor_id->setMinLength(2);
        $tipomovimento_id->setMinLength(2);

        $dataocorrencia->setDatabaseMask('yyyy-mm-dd');
        $datafinal->setDatabaseMask('yyyy-mm-dd hh:ii');
        $datainicio->setDatabaseMask('yyyy-mm-dd hh:ii');

        $cep->setMask('99.999-999');
        $setor_id->setMask('{descricao}');
        $dataocorrencia->setMask('dd/mm/yyyy');
        $datafinal->setMask('dd/mm/yyyy hh:ii');
        $datainicio->setMask('dd/mm/yyyy hh:ii');
        $tipomovimento_id->setMask('{descricao}');

        $id->setSize(92);
        $uf->setSize('70%');
        $cep->setSize('70%');
        $ibge->setSize('70%');
        $bairro->setSize('70%');
        $datafinal->setSize(142);
        $datainicio->setSize(142);
        $setor_id->setSize('70%');
        $executor->setSize('70%');
        $logradouro->setSize('72%');
        $localidade->setSize('70%');
        $dataocorrencia->setSize(92);
        $complemento->setSize('70%');
        $descricao->setSize('100%', 66);
        $tipomovimento_id->setSize('70%');

        $row1 = $this->form->addFields([new TLabel("Id:", null, '14px', null)],[$id],[new TLabel("Data:", '#ff0000', '14px', null)],[$dataocorrencia]);
        $row2 = $this->form->addFields([new TLabel("Data hora início:", '#ff0000', '14px', null)],[$datainicio],[new TLabel("Data hora final:", '#ff0000', '14px', null)],[$datafinal]);
        $row3 = $this->form->addFields([new TLabel("Setor:", null, '14px', null)],[$setor_id],[new TLabel("Tipo movimento:", null, '14px', null)],[$tipomovimento_id]);
        $row4 = $this->form->addFields([new TLabel("Descrição:", '#ff0000', '14px', null)],[$descricao]);
        $row5 = $this->form->addFields([new TLabel("Executor:", '#ff0000', '14px', null)],[$executor]);
        $row6 = $this->form->addFields([new TLabel("Cep:", null, '14px', null)],[$cep]);
        $row7 = $this->form->addFields([new TLabel("Endereço:", null, '14px', null)],[$logradouro],[new TLabel("Complemento:", null, '14px', null)],[$complemento]);
        $row8 = $this->form->addFields([new TLabel("Cidade:", null, '14px', null)],[$localidade],[new TLabel("Bairro:", null, '14px', null)],[$bairro]);
        $row9 = $this->form->addFields([new TLabel("UF:", null, '14px', null)],[$uf],[new TLabel("IBGE:", null, '14px', null)],[$ibge]);

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fa:floppy-o #ffffff');
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fa:eraser #dd5a43');

        $btn_onshow = $this->form->addAction("Retornar", new TAction(['OcorrenciaList', 'onShow']), 'fa:arrow-circle-left #0988bf');

        $btn_onaction = $this->form->addAction("Busca Cep", new TAction([$this, 'onAction']), 'fa:circle-o #000000');

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        // $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        $container->add($this->form);

        parent::add($container);

    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            /**
            // Enable Debug logger for SQL operations inside the transaction
            TTransaction::setLogger(new TLoggerSTD); // standard output
            TTransaction::setLogger(new TLoggerTXT('log.txt')); // file
            **/

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Ocorrencia(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            $object->store(); // save the object 

            $messageAction = new TAction(['OcorrenciaList', 'onShow']);   

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            /**
            // To define an action to be executed on the message close event:
            $messageAction = new TAction(['className', 'methodName']);
            **/

            new TMessage('info', AdiantiCoreTranslator::translate('Record saved'), $messageAction);

        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }
    public function onAction($param = null) 
    {
        try 
        {

            // busca cep
            $arquivo_xml = simplexml_load_file('https://viacep.com.br/ws/'.trim($param['cep']).'/xml');

            // Código gerado pelo snippet: "Enviar dados para campo"

            $object = new stdClass();
            $object->logradouro = '$arquivo_xml->logradouro';
            //$object->fieldName = 'insira o novo valor aqui'; //sample

            TForm::sendData(self::$formName, $object);
            // -----

            //code here

        }
        catch (Exception $e) 
        {
            new TMessage('error', $e->getMessage());    
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Ocorrencia($key); // instantiates the Active Record 

                $this->form->setData($object); // fill the form 

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

    }

    public function onShow($param = null)
    {

    } 

}

