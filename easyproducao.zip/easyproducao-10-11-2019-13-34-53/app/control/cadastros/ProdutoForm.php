<?php

class ProdutoForm extends TPage
{
    protected $form;
    private $formFields = [];
    private static $database = 'dbeasyproducao';
    private static $activeRecord = 'Produto';
    private static $primaryKey = 'id';
    private static $formName = 'form_Produto';

    use Adianti\Base\AdiantiMasterDetailTrait;

    /**
     * Form constructor
     * @param $param Request
     */
    public function __construct( $param )
    {
        parent::__construct();

        // creates the form
        $this->form = new BootstrapFormBuilder(self::$formName);
        // define the form title
        $this->form->setFormTitle("Cadastro de Produto");


        $id = new TEntry('id');
        $codigojiwa = new TEntry('codigojiwa');
        $descricao = new TEntry('descricao');
        $unidade = new TEntry('unidade');
        $final = new TRadioGroup('final');
        $qtdecaixa = new TEntry('qtdecaixa');
        $qtdesaco = new TEntry('qtdesaco');
        $created = new TDateTime('created');
        $modified = new TDateTime('modified');
        $produtofatorcorrecao_produto_datafator = new TDate('produtofatorcorrecao_produto_datafator');
        $produtofatorcorrecao_produto_fator = new TEntry('produtofatorcorrecao_produto_fator');
        $produtofatorcorrecao_produto_id = new THidden('produtofatorcorrecao_produto_id');

        $codigojiwa->addValidation("Codigojiwa", new TRequiredValidator()); 
        $descricao->addValidation("Descricao", new TRequiredValidator()); 
        $unidade->addValidation("Unidade", new TRequiredValidator()); 
        $final->addValidation("Final", new TRequiredValidator()); 
        $created->addValidation("Created", new TRequiredValidator()); 
        $modified->addValidation("Modified", new TRequiredValidator()); 

        $final->addItems(['S'=>'Sim','N'=>'Não']);
        $final->setLayout('horizontal');
        $final->setTip("Informe sim para itens de fabricação própria");
        $final->setBreakItems(2);

        $id->setEditable(false);
        $created->setEditable(false);
        $modified->setEditable(false);

        $final->setValue('N');
        $created->setValue(date('d/m/Y hh:ii'));
        $modified->setValue(date('d/m/Y hh:ii'));

        $created->setMask('dd/mm/yyyy hh:ii');
        $modified->setMask('dd/mm/yyyy hh:ii');
        $produtofatorcorrecao_produto_datafator->setMask('dd/mm/yyyy');

        $created->setDatabaseMask('yyyy-mm-dd hh:ii');
        $modified->setDatabaseMask('yyyy-mm-dd hh:ii');
        $produtofatorcorrecao_produto_datafator->setDatabaseMask('yyyy-mm-dd');

        $id->setSize(92);
        $final->setSize(80);
        $unidade->setSize('73%');
        $created->setSize('80%');
        $qtdesaco->setSize('73%');
        $modified->setSize('80%');
        $descricao->setSize('70%');
        $qtdecaixa->setSize('73%');
        $codigojiwa->setSize('73%');
        $produtofatorcorrecao_produto_fator->setSize('73%');
        $produtofatorcorrecao_produto_datafator->setSize('80%');

        $row1 = $this->form->addFields([new TLabel("Id:", null, '14px', null)],[$id],[new TLabel("Código legado:", '#ff0000', '14px', null)],[$codigojiwa]);
        $row2 = $this->form->addFields([new TLabel("Descrição:", '#ff0000', '14px', null)],[$descricao]);
        $row3 = $this->form->addFields([new TLabel("Unidade:", '#ff0000', '14px', null)],[$unidade],[new TLabel("Produto final:", '#ff0000', '14px', null)],[$final]);
        $row4 = $this->form->addFields([new TLabel("Qtde. caixa:", '#ff0000', '14px', null)],[$qtdecaixa],[new TLabel("Qtde. saco:", '#ff0000', '14px', null)],[$qtdesaco]);
        $row5 = $this->form->addFields([new TLabel("Criado em:", '#ff0000', '14px', null)],[$created],[new TLabel("Modificado em:", '#ff0000', '14px', null)],[$modified]);
        $row6 = $this->form->addContent([new TFormSeparator("Fator de Correção", '#333333', '18', '#eeeeee')]);
        $row7 = $this->form->addFields([new TLabel("Data:", '#ff0000', '14px', null)],[$produtofatorcorrecao_produto_datafator],[new TLabel("Fator:", '#ff0000', '14px', null)],[$produtofatorcorrecao_produto_fator]);
        $row8 = $this->form->addFields([$produtofatorcorrecao_produto_id]);         
        $add_produtofatorcorrecao_produto = new TButton('add_produtofatorcorrecao_produto');

        $action_produtofatorcorrecao_produto = new TAction(array($this, 'onAddProdutofatorcorrecaoProduto'));

        $add_produtofatorcorrecao_produto->setAction($action_produtofatorcorrecao_produto, "Adicionar");
        $add_produtofatorcorrecao_produto->setImage('fa:plus #000000');

        $this->form->addFields([$add_produtofatorcorrecao_produto]);

        $this->produtofatorcorrecao_produto_list = new BootstrapDatagridWrapper(new TQuickGrid);
        $this->produtofatorcorrecao_produto_list->style = 'width:100%';
        $this->produtofatorcorrecao_produto_list->class .= ' table-bordered';
        $this->produtofatorcorrecao_produto_list->disableDefaultClick();
        $this->produtofatorcorrecao_produto_list->addQuickColumn('', 'edit', 'left', 50);
        $this->produtofatorcorrecao_produto_list->addQuickColumn('', 'delete', 'left', 50);

        $column_produtofatorcorrecao_produto_datafator = $this->produtofatorcorrecao_produto_list->addQuickColumn("Data", 'produtofatorcorrecao_produto_datafator', 'left');
        $column_produtofatorcorrecao_produto_fator = $this->produtofatorcorrecao_produto_list->addQuickColumn("Fator", 'produtofatorcorrecao_produto_fator', 'left');

        $this->produtofatorcorrecao_produto_list->createModel();
        $this->form->addContent([$this->produtofatorcorrecao_produto_list]);

        // create the form actions
        $btn_onsave = $this->form->addAction("Salvar", new TAction([$this, 'onSave']), 'fa:floppy-o #ffffff');
        $btn_onsave->addStyleClass('btn-primary'); 

        $btn_onclear = $this->form->addAction("Limpar formulário", new TAction([$this, 'onClear']), 'fa:eraser #dd5a43');

        $btn_onshow = $this->form->addAction("Retorna", new TAction(['ProdutoList', 'onShow']), 'fa:arrow-circle-o-left #0988fb');

        // vertical box container
        $container = new TVBox;
        $container->style = 'width: 100%';
        $container->class = 'form-container';
        // $container->add(new TXMLBreadCrumb('menu.xml', __CLASS__));
        $container->add($this->form);

        parent::add($container);

    }

    public function onSave($param = null) 
    {
        try
        {
            TTransaction::open(self::$database); // open a transaction

            /**
            // Enable Debug logger for SQL operations inside the transaction
            TTransaction::setLogger(new TLoggerSTD); // standard output
            TTransaction::setLogger(new TLoggerTXT('log.txt')); // file
            **/

            $messageAction = null;

            $this->form->validate(); // validate form data

            $object = new Produto(); // create an empty object 

            $data = $this->form->getData(); // get form data as array
            $object->fromArray( (array) $data); // load the object with data

            // se não tiver id é um registro novo então devemos salvar a data de inserção do registro
            if(!$object->id) 
            {
                $object->created = date('Y-m-d H:i:s');
            }
            // sempre salvamos a data de atualização do registro
            $object->modified = date('Y-m-d H:i:s');

            $object->store(); // save the object 

            $messageAction = new TAction(['ProdutoList', 'onShow']);   

            $produtofatorcorrecao_produto_items = $this->storeItems('Produtofatorcorrecao', 'produto_id', $object, 'produtofatorcorrecao_produto', function($masterObject, $detailObject){ 

                //code here

            }); 

            // get the generated {PRIMARY_KEY}
            $data->id = $object->id; 

            $this->form->setData($data); // fill form data
            TTransaction::close(); // close the transaction

            /**
            // To define an action to be executed on the message close event:
            $messageAction = new TAction(['className', 'methodName']);
            **/

            new TMessage('info', AdiantiCoreTranslator::translate('Record saved'), $messageAction);

        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            $this->form->setData( $this->form->getData() ); // keep form data
            TTransaction::rollback(); // undo all pending operations
        }
    }

    public function onEdit( $param )
    {
        try
        {
            if (isset($param['key']))
            {
                $key = $param['key'];  // get the parameter $key
                TTransaction::open(self::$database); // open a transaction

                $object = new Produto($key); // instantiates the Active Record 

                $produtofatorcorrecao_produto_items = $this->loadItems('Produtofatorcorrecao', 'produto_id', $object, 'produtofatorcorrecao_produto', function($masterObject, $detailObject, $objectItems){ 

                    //code here

                }); 

                $this->form->setData($object); // fill the form 

                    $this->onReload();

                TTransaction::close(); // close the transaction 
            }
            else
            {
                $this->form->clear();
            }
        }
        catch (Exception $e) // in case of exception
        {
            new TMessage('error', $e->getMessage()); // shows the exception error message
            TTransaction::rollback(); // undo all pending operations
        }
    }

    /**
     * Clear form data
     * @param $param Request
     */
    public function onClear( $param )
    {
        $this->form->clear(true);

        TSession::setValue('produtofatorcorrecao_produto_items', null);

        $this->onReload();
    }

    public function onAddProdutofatorcorrecaoProduto( $param )
    {
        try
        {
            $data = $this->form->getData();

            if(!$data->produtofatorcorrecao_produto_datafator)
            {
                throw new Exception(AdiantiCoreTranslator::translate('The field ^1 is required', "Data"));
            }             
            if(!$data->produtofatorcorrecao_produto_fator)
            {
                throw new Exception(AdiantiCoreTranslator::translate('The field ^1 is required', "Fator"));
            }             

            $produtofatorcorrecao_produto_items = TSession::getValue('produtofatorcorrecao_produto_items');
            $key = isset($data->produtofatorcorrecao_produto_id) && $data->produtofatorcorrecao_produto_id ? $data->produtofatorcorrecao_produto_id : uniqid();
            $fields = []; 

            $fields['produtofatorcorrecao_produto_datafator'] = $data->produtofatorcorrecao_produto_datafator;
            $fields['produtofatorcorrecao_produto_fator'] = $data->produtofatorcorrecao_produto_fator;
            $produtofatorcorrecao_produto_items[ $key ] = $fields;

            TSession::setValue('produtofatorcorrecao_produto_items', $produtofatorcorrecao_produto_items);

            $data->produtofatorcorrecao_produto_id = '';
            $data->produtofatorcorrecao_produto_datafator = '';
            $data->produtofatorcorrecao_produto_fator = '';

            $this->form->setData($data);

            $this->onReload( $param );
        }
        catch (Exception $e)
        {
            $this->form->setData( $this->form->getData());

            new TMessage('error', $e->getMessage());
        }
    }

    public function onEditProdutofatorcorrecaoProduto( $param )
    {
        $data = $this->form->getData();

        // read session items
        $items = TSession::getValue('produtofatorcorrecao_produto_items');

        // get the session item
        $item = $items[$param['produtofatorcorrecao_produto_id_row_id']];

        $data->produtofatorcorrecao_produto_datafator = $item['produtofatorcorrecao_produto_datafator'];
        $data->produtofatorcorrecao_produto_fator = $item['produtofatorcorrecao_produto_fator'];

        $data->produtofatorcorrecao_produto_id = $param['produtofatorcorrecao_produto_id_row_id'];

        // fill product fields
        $this->form->setData( $data );

        $this->onReload( $param );

    }

    public function onDeleteProdutofatorcorrecaoProduto( $param )
    {
        $data = $this->form->getData();

        $data->produtofatorcorrecao_produto_datafator = '';
        $data->produtofatorcorrecao_produto_fator = '';

        // clear form data
        $this->form->setData( $data );

        // read session items
        $items = TSession::getValue('produtofatorcorrecao_produto_items');

        // delete the item from session
        unset($items[$param['produtofatorcorrecao_produto_id_row_id']]);
        TSession::setValue('produtofatorcorrecao_produto_items', $items);

        // reload sale items
        $this->onReload( $param );

    }

    public function onReloadProdutofatorcorrecaoProduto( $param )
    {
        $items = TSession::getValue('produtofatorcorrecao_produto_items'); 

        $this->produtofatorcorrecao_produto_list->clear(); 

        if($items) 
        { 
            $cont = 1; 
            foreach ($items as $key => $item) 
            {
                $rowItem = new StdClass;

                $action_del = new TAction(array($this, 'onDeleteProdutofatorcorrecaoProduto')); 
                $action_del->setParameter('produtofatorcorrecao_produto_id_row_id', $key);
                $action_del->setParameter('row_data', base64_encode(serialize($item)));
                $action_del->setParameter('key', $key);

                $action_edi = new TAction(array($this, 'onEditProdutofatorcorrecaoProduto'));  
                $action_edi->setParameter('produtofatorcorrecao_produto_id_row_id', $key);  
                $action_edi->setParameter('row_data', base64_encode(serialize($item)));
                $action_edi->setParameter('key', $key);

                $button_del = new TButton('delete_produtofatorcorrecao_produto'.$cont);
                $button_del->setAction($action_del, '');
                $button_del->setFormName($this->form->getName());
                $button_del->class = 'btn btn-link btn-sm';
                $button_del->title = "Excluir";
                $button_del->setImage('fa:trash-o #dd5a43');

                $rowItem->delete = $button_del;

                $button_edi = new TButton('edit_produtofatorcorrecao_produto'.$cont);
                $button_edi->setAction($action_edi, '');
                $button_edi->setFormName($this->form->getName());
                $button_edi->class = 'btn btn-link btn-sm';
                $button_edi->title = "Editar";
                $button_edi->setImage('fa:pencil-square-o #478fca');

                $rowItem->edit = $button_edi;

                $rowItem->produtofatorcorrecao_produto_datafator = isset($item['produtofatorcorrecao_produto_datafator']) ? $item['produtofatorcorrecao_produto_datafator'] : '';
                $rowItem->produtofatorcorrecao_produto_fator = isset($item['produtofatorcorrecao_produto_fator']) ? $item['produtofatorcorrecao_produto_fator'] : '';

                $row = $this->produtofatorcorrecao_produto_list->addItem($rowItem);

                $cont++;
            } 
        } 
    } 

    public function onShow($param = null)
    {
        TSession::setValue('produtofatorcorrecao_produto_items', null);

        $this->onReload();

    } 

    public function onReload($params = null)
    {
        $this->loaded = TRUE;

        $this->onReloadProdutofatorcorrecaoProduto($params);
    }

    public function show() 
    { 
        if (!$this->loaded AND (!isset($_GET['method']) OR $_GET['method'] !== 'onReload') ) 
        { 
            $this->onReload( func_get_arg(0) );
        }
        parent::show();
    }

}

