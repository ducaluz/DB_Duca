<?php

class SeparaProdutosDia extends TRecord
{
    const TABLENAME  = 'separa_produtos_dia';
    const PRIMARYKEY = 'lote_id';
    const IDPOLICY   =  'max'; // {max, serial}

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('dataproducao');
        parent::addAttribute('ordem');
        parent::addAttribute('setor');
        parent::addAttribute('produto');
        parent::addAttribute('qtde_produto');
        parent::addAttribute('un');
        parent::addAttribute('setor_id');
        parent::addAttribute('produto_id');
            
    }

    
}

