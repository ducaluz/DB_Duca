<?php

class SeparaProdutosFicha extends TRecord
{
    const TABLENAME  = 'separa_produtos_ficha';
    const PRIMARYKEY = 'ordemproducao_id';
    const IDPOLICY   =  'max'; // {max, serial}

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('dataproducao');
        parent::addAttribute('quantidade_ficha');
        parent::addAttribute('fichatecnica_id');
        parent::addAttribute('descricao_ficha');
        parent::addAttribute('produto');
        parent::addAttribute('qtde_produto');
        parent::addAttribute('un');
        parent::addAttribute('setor');
        parent::addAttribute('lote_id');
            
    }

    
}

