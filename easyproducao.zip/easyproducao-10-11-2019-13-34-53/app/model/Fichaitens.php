<?php

class Fichaitens extends TRecord
{
    const TABLENAME  = 'fichaitens';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private $fichatecnica;
    private $produto;
    private $setor;

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('quantidade');
        parent::addAttribute('tempo');
        parent::addAttribute('fichatecnica_id');
        parent::addAttribute('produto_id');
        parent::addAttribute('setor_id');
        parent::addAttribute('observacao');
            
    }

    /**
     * Method set_fichatecnica
     * Sample of usage: $var->fichatecnica = $object;
     * @param $object Instance of Fichatecnica
     */
    public function set_fichatecnica(Fichatecnica $object)
    {
        $this->fichatecnica = $object;
        $this->fichatecnica_id = $object->id;
    }

    /**
     * Method get_fichatecnica
     * Sample of usage: $var->fichatecnica->attribute;
     * @returns Fichatecnica instance
     */
    public function get_fichatecnica()
    {
    
        // loads the associated object
        if (empty($this->fichatecnica))
            $this->fichatecnica = new Fichatecnica($this->fichatecnica_id);
    
        // returns the associated object
        return $this->fichatecnica;
    }
    /**
     * Method set_produto
     * Sample of usage: $var->produto = $object;
     * @param $object Instance of Produto
     */
    public function set_produto(Produto $object)
    {
        $this->produto = $object;
        $this->produto_id = $object->id;
    }

    /**
     * Method get_produto
     * Sample of usage: $var->produto->attribute;
     * @returns Produto instance
     */
    public function get_produto()
    {
    
        // loads the associated object
        if (empty($this->produto))
            $this->produto = new Produto($this->produto_id);
    
        // returns the associated object
        return $this->produto;
    }
    /**
     * Method set_setor
     * Sample of usage: $var->setor = $object;
     * @param $object Instance of Setor
     */
    public function set_setor(Setor $object)
    {
        $this->setor = $object;
        $this->setor_id = $object->id;
    }

    /**
     * Method get_setor
     * Sample of usage: $var->setor->attribute;
     * @returns Setor instance
     */
    public function get_setor()
    {
    
        // loads the associated object
        if (empty($this->setor))
            $this->setor = new Setor($this->setor_id);
    
        // returns the associated object
        return $this->setor;
    }

    
}

