<?php

class Setor extends TRecord
{
    const TABLENAME  = 'setor';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('descricao');
        parent::addAttribute('capacidade');
        parent::addAttribute('localestoque');
        parent::addAttribute('created');
        parent::addAttribute('modified');
        parent::addAttribute('ordem');
            
    }

    /**
     * Method getFichaitenss
     */
    public function getFichaitenss()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('setor_id', '=', $this->id));
        return Fichaitens::getObjects( $criteria );
    }
    /**
     * Method getMovimentoproducaos
     */
    public function getMovimentoproducaos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('setor_id', '=', $this->id));
        return Movimentoproducao::getObjects( $criteria );
    }
    /**
     * Method getOcorrencias
     */
    public function getOcorrencias()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('setor_id', '=', $this->id));
        return Ocorrencia::getObjects( $criteria );
    }
    /**
     * Method getLoteitenss
     */
    public function getLoteitenss()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('setor_id', '=', $this->id));
        return Loteitens::getObjects( $criteria );
    }

    
}

