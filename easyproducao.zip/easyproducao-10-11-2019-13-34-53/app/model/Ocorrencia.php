<?php

class Ocorrencia extends TRecord
{
    const TABLENAME  = 'ocorrencia';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private $setor;
    private $tipomovimento;

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('dataocorrencia');
        parent::addAttribute('datainicio');
        parent::addAttribute('datafinal');
        parent::addAttribute('descricao');
        parent::addAttribute('setor_id');
        parent::addAttribute('tipomovimento_id');
        parent::addAttribute('executor');
            
    }

    /**
     * Method set_setor
     * Sample of usage: $var->setor = $object;
     * @param $object Instance of Setor
     */
    public function set_setor(Setor $object)
    {
        $this->setor = $object;
        $this->setor_id = $object->id;
    }

    /**
     * Method get_setor
     * Sample of usage: $var->setor->attribute;
     * @returns Setor instance
     */
    public function get_setor()
    {
    
        // loads the associated object
        if (empty($this->setor))
            $this->setor = new Setor($this->setor_id);
    
        // returns the associated object
        return $this->setor;
    }
    /**
     * Method set_tipomovimento
     * Sample of usage: $var->tipomovimento = $object;
     * @param $object Instance of Tipomovimento
     */
    public function set_tipomovimento(Tipomovimento $object)
    {
        $this->tipomovimento = $object;
        $this->tipomovimento_id = $object->id;
    }

    /**
     * Method get_tipomovimento
     * Sample of usage: $var->tipomovimento->attribute;
     * @returns Tipomovimento instance
     */
    public function get_tipomovimento()
    {
    
        // loads the associated object
        if (empty($this->tipomovimento))
            $this->tipomovimento = new Tipomovimento($this->tipomovimento_id);
    
        // returns the associated object
        return $this->tipomovimento;
    }

    
}

