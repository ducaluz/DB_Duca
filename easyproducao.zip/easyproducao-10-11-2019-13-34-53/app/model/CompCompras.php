<?php

class CompCompras extends TRecord
{
    const TABLENAME  = 'comp_compras';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
            
    }

    /**
     * Method getCompDetalhess
     */
    public function getCompDetalhess()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('comp_compras_id', '=', $this->id));
        return CompDetalhes::getObjects( $criteria );
    }

    
}

