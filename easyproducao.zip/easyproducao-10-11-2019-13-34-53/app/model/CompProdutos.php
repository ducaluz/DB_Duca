<?php

class CompProdutos extends TRecord
{
    const TABLENAME  = 'comp_produtos';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
            
    }

    /**
     * Method getCompProdutosvols
     */
    public function getCompProdutosvols()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('comp_produtos_id', '=', $this->id));
        return CompProdutosvol::getObjects( $criteria );
    }

    
}

