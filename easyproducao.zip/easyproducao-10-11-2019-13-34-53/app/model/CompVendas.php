<?php

class CompVendas extends TRecord
{
    const TABLENAME  = 'comp_vendas';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
            
    }

    /**
     * Method getCompVendasdetalhes
     */
    public function getCompVendasdetalhes()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('comp_vendas_id', '=', $this->id));
        return CompVendasdetalhe::getObjects( $criteria );
    }

    
}

