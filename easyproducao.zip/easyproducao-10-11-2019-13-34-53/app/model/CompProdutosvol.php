<?php

class CompProdutosvol extends TRecord
{
    const TABLENAME  = 'comp_produtosvol';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private $comp_produtos;

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('comp_produtos_id');
            
    }

    /**
     * Method set_comp_produtos
     * Sample of usage: $var->comp_produtos = $object;
     * @param $object Instance of CompProdutos
     */
    public function set_comp_produtos(CompProdutos $object)
    {
        $this->comp_produtos = $object;
        $this->comp_produtos_id = $object->id;
    }

    /**
     * Method get_comp_produtos
     * Sample of usage: $var->comp_produtos->attribute;
     * @returns CompProdutos instance
     */
    public function get_comp_produtos()
    {
    
        // loads the associated object
        if (empty($this->comp_produtos))
            $this->comp_produtos = new CompProdutos($this->comp_produtos_id);
    
        // returns the associated object
        return $this->comp_produtos;
    }

    
}

