<?php

class CompRequest extends TRecord
{
    const TABLENAME  = 'comp_request';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private $fk_ordemproducao;

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('ordemproducao');
        parent::addAttribute('sequencia');
        parent::addAttribute('codprod');
        parent::addAttribute('qtdneg');
        parent::addAttribute('codemp');
        parent::addAttribute('codlocalorig');
        parent::addAttribute('codlocaldest');
        parent::addAttribute('dhinc');
        parent::addAttribute('dhalter');
        parent::addAttribute('dhsync');
        parent::addAttribute('tipo');
            
    }

    /**
     * Method set_ordemproducao
     * Sample of usage: $var->ordemproducao = $object;
     * @param $object Instance of Ordemproducao
     */
    public function set_fk_ordemproducao(Ordemproducao $object)
    {
        $this->fk_ordemproducao = $object;
        $this->ordemproducao = $object->id;
    }

    /**
     * Method get_fk_ordemproducao
     * Sample of usage: $var->fk_ordemproducao->attribute;
     * @returns Ordemproducao instance
     */
    public function get_fk_ordemproducao()
    {
        TTransaction::open('dbeasyproducao');
        // loads the associated object
        if (empty($this->fk_ordemproducao))
            $this->fk_ordemproducao = new Ordemproducao($this->ordemproducao);
        TTransaction::close();
        // returns the associated object
        return $this->fk_ordemproducao;
    }

    
}

