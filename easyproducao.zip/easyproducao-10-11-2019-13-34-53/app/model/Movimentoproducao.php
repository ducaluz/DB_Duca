<?php

class Movimentoproducao extends TRecord
{
    const TABLENAME  = 'movimentoproducao';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private $ordem;
    private $setor;
    private $tipomovimento;

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('datamovimento');
        parent::addAttribute('tipomovimento_id');
        parent::addAttribute('ordem_id');
        parent::addAttribute('setor_id');
        parent::addAttribute('quantidade');
            
    }

    /**
     * Method set_ordemproducao
     * Sample of usage: $var->ordemproducao = $object;
     * @param $object Instance of Ordemproducao
     */
    public function set_ordem(Ordemproducao $object)
    {
        $this->ordem = $object;
        $this->ordem_id = $object->id;
    }

    /**
     * Method get_ordem
     * Sample of usage: $var->ordem->attribute;
     * @returns Ordemproducao instance
     */
    public function get_ordem()
    {
    
        // loads the associated object
        if (empty($this->ordem))
            $this->ordem = new Ordemproducao($this->ordem_id);
    
        // returns the associated object
        return $this->ordem;
    }
    /**
     * Method set_setor
     * Sample of usage: $var->setor = $object;
     * @param $object Instance of Setor
     */
    public function set_setor(Setor $object)
    {
        $this->setor = $object;
        $this->setor_id = $object->id;
    }

    /**
     * Method get_setor
     * Sample of usage: $var->setor->attribute;
     * @returns Setor instance
     */
    public function get_setor()
    {
    
        // loads the associated object
        if (empty($this->setor))
            $this->setor = new Setor($this->setor_id);
    
        // returns the associated object
        return $this->setor;
    }
    /**
     * Method set_tipomovimento
     * Sample of usage: $var->tipomovimento = $object;
     * @param $object Instance of Tipomovimento
     */
    public function set_tipomovimento(Tipomovimento $object)
    {
        $this->tipomovimento = $object;
        $this->tipomovimento_id = $object->id;
    }

    /**
     * Method get_tipomovimento
     * Sample of usage: $var->tipomovimento->attribute;
     * @returns Tipomovimento instance
     */
    public function get_tipomovimento()
    {
    
        // loads the associated object
        if (empty($this->tipomovimento))
            $this->tipomovimento = new Tipomovimento($this->tipomovimento_id);
    
        // returns the associated object
        return $this->tipomovimento;
    }

    
}

