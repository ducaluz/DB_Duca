<?php

class Produto extends TRecord
{
    const TABLENAME  = 'produto';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('descricao');
        parent::addAttribute('unidade');
        parent::addAttribute('final');
        parent::addAttribute('created');
        parent::addAttribute('modified');
        parent::addAttribute('codigojiwa');
        parent::addAttribute('qtdecaixa');
        parent::addAttribute('qtdesaco');
            
    }

    /**
     * Method getFichaitenss
     */
    public function getFichaitenss()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('produto_id', '=', $this->id));
        return Fichaitens::getObjects( $criteria );
    }
    /**
     * Method getProdutofatorcorrecaos
     */
    public function getProdutofatorcorrecaos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('produto_id', '=', $this->id));
        return Produtofatorcorrecao::getObjects( $criteria );
    }
    /**
     * Method getFichatecnicas
     */
    public function getFichatecnicas()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('produto_id', '=', $this->id));
        return Fichatecnica::getObjects( $criteria );
    }

    
}

