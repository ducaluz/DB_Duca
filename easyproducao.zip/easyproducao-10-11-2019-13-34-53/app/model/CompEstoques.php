<?php

class CompEstoques extends TRecord
{
    const TABLENAME  = 'comp_estoques';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
            
    }

    
}

