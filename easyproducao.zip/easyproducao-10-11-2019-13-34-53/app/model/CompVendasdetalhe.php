<?php

class CompVendasdetalhe extends TRecord
{
    const TABLENAME  = 'comp_vendasdetalhe';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private $comp_vendas;

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('comp_vendas_id');
            
    }

    /**
     * Method set_comp_vendas
     * Sample of usage: $var->comp_vendas = $object;
     * @param $object Instance of CompVendas
     */
    public function set_comp_vendas(CompVendas $object)
    {
        $this->comp_vendas = $object;
        $this->comp_vendas_id = $object->id;
    }

    /**
     * Method get_comp_vendas
     * Sample of usage: $var->comp_vendas->attribute;
     * @returns CompVendas instance
     */
    public function get_comp_vendas()
    {
    
        // loads the associated object
        if (empty($this->comp_vendas))
            $this->comp_vendas = new CompVendas($this->comp_vendas_id);
    
        // returns the associated object
        return $this->comp_vendas;
    }

    
}

