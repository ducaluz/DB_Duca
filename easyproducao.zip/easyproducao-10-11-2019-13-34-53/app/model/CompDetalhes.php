<?php

class CompDetalhes extends TRecord
{
    const TABLENAME  = 'comp_detalhes';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private $comp_compras;

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('comp_compras_id');
            
    }

    /**
     * Method set_comp_compras
     * Sample of usage: $var->comp_compras = $object;
     * @param $object Instance of CompCompras
     */
    public function set_comp_compras(CompCompras $object)
    {
        $this->comp_compras = $object;
        $this->comp_compras_id = $object->id;
    }

    /**
     * Method get_comp_compras
     * Sample of usage: $var->comp_compras->attribute;
     * @returns CompCompras instance
     */
    public function get_comp_compras()
    {
    
        // loads the associated object
        if (empty($this->comp_compras))
            $this->comp_compras = new CompCompras($this->comp_compras_id);
    
        // returns the associated object
        return $this->comp_compras;
    }

    
}

