<?php

class Tipomovimento extends TRecord
{
    const TABLENAME  = 'tipomovimento';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('descricao');
        parent::addAttribute('created');
        parent::addAttribute('modified');
        parent::addAttribute('entradasaida');
            
    }

    /**
     * Method getMovimentoproducaos
     */
    public function getMovimentoproducaos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('tipomovimento_id', '=', $this->id));
        return Movimentoproducao::getObjects( $criteria );
    }
    /**
     * Method getOcorrencias
     */
    public function getOcorrencias()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('tipomovimento_id', '=', $this->id));
        return Ocorrencia::getObjects( $criteria );
    }

    
}

