<?php

class Ordemproducao extends TRecord
{
    const TABLENAME  = 'ordemproducao';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private $fichatecnica;
    private $loteitens;

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('dataproducao');
        parent::addAttribute('quantidade');
        parent::addAttribute('status');
        parent::addAttribute('fichatecnica_id');
        parent::addAttribute('loteitens_id');
            
    }

    /**
     * Method set_fichatecnica
     * Sample of usage: $var->fichatecnica = $object;
     * @param $object Instance of Fichatecnica
     */
    public function set_fichatecnica(Fichatecnica $object)
    {
        $this->fichatecnica = $object;
        $this->fichatecnica_id = $object->id;
    }

    /**
     * Method get_fichatecnica
     * Sample of usage: $var->fichatecnica->attribute;
     * @returns Fichatecnica instance
     */
    public function get_fichatecnica()
    {
    
        // loads the associated object
        if (empty($this->fichatecnica))
            $this->fichatecnica = new Fichatecnica($this->fichatecnica_id);
    
        // returns the associated object
        return $this->fichatecnica;
    }
    /**
     * Method set_loteitens
     * Sample of usage: $var->loteitens = $object;
     * @param $object Instance of Loteitens
     */
    public function set_loteitens(Loteitens $object)
    {
        $this->loteitens = $object;
        $this->loteitens_id = $object->id;
    }

    /**
     * Method get_loteitens
     * Sample of usage: $var->loteitens->attribute;
     * @returns Loteitens instance
     */
    public function get_loteitens()
    {
    
        // loads the associated object
        if (empty($this->loteitens))
            $this->loteitens = new Loteitens($this->loteitens_id);
    
        // returns the associated object
        return $this->loteitens;
    }

    /**
     * Method getMovimentoproducaos
     */
    public function getMovimentoproducaos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('ordem_id', '=', $this->id));
        return Movimentoproducao::getObjects( $criteria );
    }
    /**
     * Method getCompRequests
     */
    public function getCompRequests()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('ordemproducao', '=', $this->id));
        return CompRequest::getObjects( $criteria );
    }

    
}

