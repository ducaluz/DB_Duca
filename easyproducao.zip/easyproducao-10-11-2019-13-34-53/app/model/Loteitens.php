<?php

class Loteitens extends TRecord
{
    const TABLENAME  = 'loteitens';
    const PRIMARYKEY = 'id';
    const IDPOLICY   =  'serial'; // {max, serial}

    private $lote;
    private $fichatecnica;
    private $setor;

    

    /**
     * Constructor method
     */
    public function __construct($id = NULL, $callObjectLoad = TRUE)
    {
        parent::__construct($id, $callObjectLoad);
        parent::addAttribute('lote_id');
        parent::addAttribute('fichatecnica_id');
        parent::addAttribute('quantidade');
        parent::addAttribute('setor_id');
            
    }

    /**
     * Method set_lote
     * Sample of usage: $var->lote = $object;
     * @param $object Instance of Lote
     */
    public function set_lote(Lote $object)
    {
        $this->lote = $object;
        $this->lote_id = $object->id;
    }

    /**
     * Method get_lote
     * Sample of usage: $var->lote->attribute;
     * @returns Lote instance
     */
    public function get_lote()
    {
    
        // loads the associated object
        if (empty($this->lote))
            $this->lote = new Lote($this->lote_id);
    
        // returns the associated object
        return $this->lote;
    }
    /**
     * Method set_fichatecnica
     * Sample of usage: $var->fichatecnica = $object;
     * @param $object Instance of Fichatecnica
     */
    public function set_fichatecnica(Fichatecnica $object)
    {
        $this->fichatecnica = $object;
        $this->fichatecnica_id = $object->id;
    }

    /**
     * Method get_fichatecnica
     * Sample of usage: $var->fichatecnica->attribute;
     * @returns Fichatecnica instance
     */
    public function get_fichatecnica()
    {
    
        // loads the associated object
        if (empty($this->fichatecnica))
            $this->fichatecnica = new Fichatecnica($this->fichatecnica_id);
    
        // returns the associated object
        return $this->fichatecnica;
    }
    /**
     * Method set_setor
     * Sample of usage: $var->setor = $object;
     * @param $object Instance of Setor
     */
    public function set_setor(Setor $object)
    {
        $this->setor = $object;
        $this->setor_id = $object->id;
    }

    /**
     * Method get_setor
     * Sample of usage: $var->setor->attribute;
     * @returns Setor instance
     */
    public function get_setor()
    {
    
        // loads the associated object
        if (empty($this->setor))
            $this->setor = new Setor($this->setor_id);
    
        // returns the associated object
        return $this->setor;
    }

    /**
     * Method getOrdemproducaos
     */
    public function getOrdemproducaos()
    {
        $criteria = new TCriteria;
        $criteria->add(new TFilter('loteitens_id', '=', $this->id));
        return Ordemproducao::getObjects( $criteria );
    }

    
}

